# CoilGen Design Report

Generated with **CoilGen2**. Created and maintained by Philipp Amrein — MRI hardware engineer.

Original CoilGen reference: [Amrein P, Jia F, Zaitsev M, Littin S. CoilGen: Open-source MR coil layout generator. Magnetic Resonance in Medicine. 2022;88(3):1465–1479.](https://doi.org/10.1002/mrm.29294)

Execution status: **completed**
Engineering acceptance: **FAIL** (reported checks only)
Unassessed engineering checks and construction release are excluded from this status.
Design context: **mr_shim**

## Failures

- Route-quality diagnostics report at least one failed coil part.
- Manufacturing diagnostics report invalid swept-body geometry.

## Warnings

- [WARNING] layout_terminal_strategy: Connected-layout routing has no terminal handling strategy. Suggestion: Set pads, wire_stubs, or waived when the result is intended for manufacturing review.
- [WARNING] layout_terminal_strategy: Swept-body export is enabled without explicit terminal handling. Suggestion: Define terminal pads/wire stubs or mark terminal handling as waived.
- [WARNING] conductor_mounting_mode: Manufacturing conductor centerline is offset from the electromagnetic wire path. Suggestion: Use centered mode for exact field-evaluation consistency, or re-evaluate fields with the shifted manufacturing path.

## Magnetostatic Feasibility

| Quantity | Value |
|---|---:|
| `overall_status` | FAIL |
| `target_point_count` | 257 |
| `dsv_target_point_count` | 257 |
| `layout_gradient_efficiency_mT_per_m_per_A` | nan |
| `layout_needed_current_A` | 1.75156 |
| `layout_mean_rel_error_percent` | 5.50274 |
| `layout_max_rel_error_percent` | 9.16898 |
| `shim_layout_residual_rms_T` | 5.76417e-07 |
| `shim_layout_residual_max_abs_T` | 9.16898e-07 |
| `target_error_constraint_met` | True |
| `dsv_constraint_met` | True |
| `constrained_solver_contract_met` | True |
| `constrained_solver_physical_constraints_met` | True |
| `constrained_solver_diagnostic_result` | False |
| `constrained_solver_failed_constraints` |  |

## Layout Feasibility

| Quantity | Value |
|---|---:|
| `layout_status` | FAIL |
| `route_statuses` | fail |
| `contour_count` | 37 |
| `topological_group_count` | 11 |
| `min_contour_distance_m` | nan |
| `unconnected_contours_min_wire_distance_m` | nan |
| `min_wire_wire_distance_m` | 1.84175e-18 |
| `wire_clearance_failure_threshold_m` | 0 |
| `wire_clearance_failure_count` | 0 |
| `current_density_class` | continuous_candidate |
| `finished_engineering_design_ready` | False |

## Engineering Checks Not Included

| Quantity | Value |
|---|---:|
| `engineering_readiness_status` | screening_only |
| `finished_engineering_design_ready` | False |
| `magnetostatic_status` | FAIL |
| `layout_status` | FAIL |
| `engineering_checks_not_included` | thermal; gradient-driver voltage/current margin; slew-rate validation; PNS; acoustic response; Lorentz force and torque; eddy-current coupling; cryostat or nearby-conductor heating; mechanical stress; terminal routing validation |

## Suppression-Clearance Report

Checks generated zero-field suppression target points against the source mesh used for clearance validation.

| Quantity | Value |
|---|---:|
| `suppression_clearance_status` | not_applicable |
| `suppression_clearance_generator` |  |
| `suppression_clearance_action` |  |
| `suppression_clearance_requested_m` | nan |
| `suppression_clearance_min_allowed_m` | nan |
| `suppression_clearance_min_m` | nan |
| `suppression_clearance_p05_m` | nan |
| `suppression_clearance_median_m` | nan |
| `suppression_clearance_max_m` | nan |
| `suppression_clearance_input_vertex_count` | 0 |
| `suppression_clearance_output_vertex_count` | 0 |
| `suppression_clearance_output_face_count` | 0 |
| `suppression_clearance_dropped_face_count` | 0 |
| `suppression_clearance_violation_count` | 0 |
| `suppression_clearance_warning` |  |

## Numerical Summary

| Quantity | Value |
|---|---:|
| `report_schema_version` | coilgen-report-v1 |
| `execution_status` | completed |
| `engineering_acceptance_status` | FAIL |
| `engineering_status` | FAIL |
| `engineering_acceptance_scope` | Reported checks only; unassessed checks and construction release are excluded. |
| `quality_status` | FAIL |
| `quality_failures` | Route-quality diagnostics report at least one failed coil part.; Manufacturing diagnostics report invalid swept-body geometry. |
| `quality_warnings` |  |
| `first_failing_check` | Route-quality diagnostics report at least one failed coil part. |
| `first_failure` | Route-quality diagnostics report at least one failed coil part. |
| `target_error_constraint_status` | PASS |
| `dsv_constraint_status` | PASS |
| `suppression_constraint_status` | inactive |
| `linearity_rms_constraint_status` | inactive |
| `linearity_peak_constraint_status` | inactive |
| `gradient_strength_constraint_status` | inactive |
| `cross_gradient_constraint_status` | inactive |
| `shield_gradient_opposition_constraint_status` | inactive |
| `software_name` | CoilGen2 |
| `software_creator` | Philipp Amrein |
| `software_maintainer` | Philipp Amrein |
| `software_creator_role` | MRI hardware engineer |
| `software_repository` | https://github.com/Philipp-MR/Coilgen2 |
| `software_original_coilgen_doi` | 10.1002/mrm.29294 |
| `problem_schema_version` |  |
| `design_context` | mr_shim |
| `design_context_is_mr` | True |
| `design_context_evaluation_features` | electrical, field_error, manufacturing, routing, shim_homogeneity, shim_spherical_harmonics |
| `target_field_component` | Bz |
| `field_evaluation_current_source` | stream_function |
| `routing_field_acceptance_policies` |  |
| `routing_absolute_field_contract_status` | not_checked |
| `routing_absolute_field_contract_failed_part_count` | 0 |
| `routing_absolute_field_contract_failure_reasons` |  |
| `routing_clearance_target_m` | 0.00166421 |
| `routing_source_contour_clearance_m` | 0 |
| `routing_physical_minimum_centerline_distance_m` | nan |
| `routing_physical_clearance_lower_bound_m` | nan |
| `field_source_label` | Bz target, stream_function current |
| `layout_terminal_strategy` | undefined |
| `layout_terminal_pad_count` | 0 |
| `layout_terminal_exit_count` | 0 |
| `layout_keepout_region_count` | 0 |
| `layout_manufacturing_intent` |  |
| `part_count` | 1 |
| `target_point_count` | 257 |
| `dsv_target_point_count` | 257 |
| `suppression_point_count` | 0 |
| `target_field_units` | T |
| `field_display_units` | T |
| `proton_frequency_Hz_per_T` | 4.25775e+07 |
| `shim_layout_residual_sample_count` | 257 |
| `shim_layout_residual_mean_T` | 5.46565e-07 |
| `shim_layout_residual_median_T` | 5.04075e-07 |
| `shim_layout_residual_std_T` | 1.83095e-07 |
| `shim_layout_residual_rms_T` | 5.76417e-07 |
| `shim_layout_residual_p95_abs_T` | 8.42523e-07 |
| `shim_layout_residual_max_abs_T` | 9.16898e-07 |
| `shim_layout_residual_peak_to_peak_T` | 1.39346e-06 |
| `shim_stream_function_residual_sample_count` | 257 |
| `shim_stream_function_residual_mean_T` | -1.25896e-10 |
| `shim_stream_function_residual_median_T` | -1.07383e-09 |
| `shim_stream_function_residual_std_T` | 8.51297e-08 |
| `shim_stream_function_residual_rms_T` | 8.51298e-08 |
| `shim_stream_function_residual_p95_abs_T` | 1.39563e-07 |
| `shim_stream_function_residual_max_abs_T` | 7.00086e-07 |
| `shim_stream_function_residual_peak_to_peak_T` | 8.39649e-07 |
| `contour_count` | 37 |
| `nominal_contour_geometry_count` | 37 |
| `physical_turn_count` | 37 |
| `contour_sparsification_mode` | off |
| `contour_sparsification_accepted_merge_count` | 0 |
| `contour_sparsification_completed_pass_count` | 0 |
| `contour_sparsification_achieved_max_turn_multiplicity` | 0 |
| `contour_sparsification_global_rms_field_error_percent` | 0 |
| `contour_sparsification_global_peak_field_error_percent` | 0 |
| `contour_sparsification_merge_rms_field_error_percent` | 0 |
| `contour_sparsification_merge_peak_field_error_percent` | 0 |
| `contour_sparsification_residual_budget_enabled` | False |
| `contour_sparsification_residual_baseline_metric_T` | nan |
| `contour_sparsification_residual_allowed_metric_T` | nan |
| `contour_sparsification_merge_selected_residual_metric_T` | nan |
| `contour_sparsification_merge_residual_metric_change_T` | nan |
| `contour_sparsification_pruning_mode` | off |
| `contour_sparsification_pruning_removed_geometry_count` | 0 |
| `contour_sparsification_pruning_removed_turn_count` | 0 |
| `contour_sparsification_pruning_baseline_metric_T` | nan |
| `contour_sparsification_pruning_selected_metric_T` | nan |
| `contour_sparsification_pruning_metric_change_T` | nan |
| `contour_sparsification_pruning_incremental_rms_field_error_percent` | 0 |
| `contour_sparsification_pruning_incremental_peak_field_error_percent` | 0 |
| `topological_group_count` | 11 |
| `effective_contour_levels` | 12 |
| `contour_discretization_method` | level_count |
| `max_wire_current_A` | 0 |
| `min_wire_distance_m` | 0 |
| `engineering_max_contour_step_A` | 0 |
| `engineering_required_contour_step_A` | nan |
| `engineering_current_limit_feasible` | True |
| `surface_current_density_limit_A_per_m` | 0 |
| `surface_current_density_limit_met` | True |
| `surface_current_density_max_A_per_m` | 450.055 |
| `surface_current_density_p99_A_per_m` | 449.396 |
| `target_gradient_normalization_method` | none |
| `target_gradient_axis` | y |
| `target_gradient_requested_T_per_m` | 0.02 |
| `target_gradient_hardware_effective_T_per_m` | 2.40178e-21 |
| `gradient_hardware_feasible` | True |
| `gradient_hardware_scale_factor` | nan |
| `linearity_enabled` | False |
| `linearity_applicable` | False |
| `linearity_status` | not_applicable |
| `linearity_met` | True |
| `linearity_failure_reasons` |  |
| `linearity_region` | dsv |
| `linearity_normalization` | requested_gradient_times_radius |
| `linearity_fit_offset` | True |
| `linearity_reference_radius_m` | 0.05 |
| `linearity_reference_scale_T` | 0.001 |
| `linearity_requested_gradient_T_per_m` | 0.02 |
| `linearity_desired_gradient_T_per_m` | 6.00446e-21 |
| `linearity_achieved_gradient_T_per_m` | 7.33021e-06 |
| `linearity_gradient_strength_error_percent` | nan |
| `linearity_gradient_strength_tolerance_percent` | 0 |
| `linearity_gradient_strength_met` | True |
| `linearity_gradient_strength_status` | not_applicable |
| `linearity_cross_gradient_T_per_m` | 3.58302e-08 |
| `linearity_cross_gradient_percent` | nan |
| `linearity_cross_gradient_tolerance_percent` | 0 |
| `linearity_cross_gradient_met` | True |
| `linearity_cross_gradient_status` | not_applicable |
| `linearity_rms_residual_T` | 2.78316e-06 |
| `linearity_p95_abs_residual_T` | 5.17184e-06 |
| `linearity_peak_abs_residual_T` | 9.5125e-06 |
| `linearity_rms_percent` | nan |
| `linearity_p95_percent` | nan |
| `linearity_peak_percent` | nan |
| `linearity_rms_tolerance_percent` | 0 |
| `linearity_peak_tolerance_percent` | 0 |
| `linearity_rms_met` | True |
| `linearity_peak_met` | True |
| `linearity_rms_status` | not_applicable |
| `linearity_peak_status` | not_applicable |
| `linearity_sample_count` | 257 |
| `contourability_checked` | False |
| `contourability_ok` | True |
| `contourability_repaired` | False |
| `contourability_reason` |  |
| `contourability_requested_levels` | 12 |
| `contourability_selected_levels` | 12 |
| `contourability_field_rms_error_percent` | nan |
| `contourability_field_mean_abs_error_percent` | nan |
| `contourability_field_peak_error_percent` | nan |
| `contourability_total_length_m` | nan |
| `layout_target_checked` | False |
| `layout_target_met` | True |
| `layout_target_metric` |  |
| `layout_target_metric_T` | 5.76417e-07 |
| `layout_target_limit_T` | nan |
| `layout_target_effective_limit_T` | nan |
| `layout_target_metric_ratio` | nan |
| `layout_target_source` | fabricated_centroid |
| `contourability_target_metric_T` | nan |
| `contourability_target_allowed_metric_T` | nan |
| `contour_field_smoothing_applied` | False |
| `contour_field_smoothing_improvement_percent` | nan |
| `contour_path_smoothing_scale_mode` | mesh_coupled |
| `contour_path_smoothing_mesh_scale_m` | 0.0280704 |
| `contour_path_smoothing_mesh_gain_requested` | 0.1 |
| `contour_path_smoothing_mesh_gain_applied` | 0.1 |
| `contour_path_smoothing_displacement_cap_enabled` | True |
| `contour_path_smoothing_max_applied_displacement_m` | 0.000495277 |
| `contour_path_smoothing_contour_count` | 16 |
| `contour_path_smoothing_spacing_rejected_count` | 0 |
| `contour_loop_pruning_mode` | off |
| `contour_loop_pruning_raw_loop_count` | 0 |
| `contour_loop_pruning_significance_removed_loop_count` | 0 |
| `contour_loop_pruning_removed_loop_count` | 0 |
| `contour_loop_pruning_baseline_metric_T` | nan |
| `contour_loop_pruning_allowed_metric_T` | nan |
| `contour_loop_pruning_selected_metric_T` | nan |
| `contour_loop_pruning_metric_change_T` | nan |
| `contour_loop_pruning_symmetry_grouping_complete` | False |
| `potential_step_A` | 1.75156 |
| `needed_current_A` | 1.75156 |
| `coil_length_m` | 35.8033 |
| `coil_length_total_m` | 35.8033 |
| `coil_electrical_calculation_status` | enabled |
| `coil_resistance_ohm` | 0.64446 |
| `coil_resistance_total_ohm` | 0.64446 |
| `coil_inductance_H` | 0.000114962 |
| `coil_inductance_same_current_H` | 0.000114962 |
| `min_contour_distance_m` | nan |
| `unconnected_contours_min_wire_distance_m` | nan |
| `min_wire_wire_distance_m` | 1.84175e-18 |
| `wire_clearance_failure_count` | 0 |
| `wire_clearance_failure_threshold_m` | 0 |
| `wire_clearance_warning_count` | 1 |
| `wire_clearance_warning_threshold_m` | 0.001 |
| `route_statuses` | fail |
| `stream_function_scheme` | research_convex |
| `regularization_method` | research_convex |
| `regularization_factor` | 0 |
| `regularization_lambda` | 0 |
| `regularization_auto_range` | False |
| `estimated_regularization_contour_step_A` | nan |
| `regularization_auto_range_max_contour_step_A` | nan |
| `target_error_contour_step_guard_relaxed_for_constraint` | False |
| `contour_step_constraint_enabled` | False |
| `contour_step_constraint_source` |  |
| `contour_step_constraint_max_step_A` | nan |
| `contour_step_constraint_level_count` | 0 |
| `contour_step_constraint_max_range_A` | nan |
| `surface_current_density_constraint_enabled` | False |
| `surface_current_density_constraint_source` |  |
| `surface_current_density_constraint_limit_A_per_m` | nan |
| `surface_current_density_constraint_derived_limit_A_per_m` | nan |
| `shield_gradient_opposition_requested` | False |
| `shield_gradient_opposition_enabled` | False |
| `shield_gradient_opposition_constraint_met` | True |
| `shield_gradient_opposition_value_T_per_m` | nan |
| `shield_gradient_opposition_limit_T_per_m` | nan |
| `shield_gradient_opposition_margin_T_per_m` | nan |
| `shield_gradient_opposition_reason` |  |
| `shield_gradient_opposition_part_indices` |  |
| `estimated_guarded_contour_step_A` | nan |
| `target_error_constraint_mode` | separate |
| `target_error_constraint_metric` | norm |
| `target_error_constraint_met` | True |
| `target_error_tolerance_percent` | 4 |
| `target_error_constraint_relative_residual_percent` | 3.06122 |
| `target_error_constraint_field_metric_T` | 1.36473e-06 |
| `target_error_allowed_field_metric_T` | 1.78326e-06 |
| `linearity_rms_constraint_met` | False |
| `linearity_rms_constraint_field_metric_T` | nan |
| `linearity_rms_constraint_allowed_field_metric_T` | nan |
| `linearity_peak_constraint_met` | False |
| `linearity_peak_constraint_field_metric_T` | nan |
| `linearity_peak_constraint_allowed_field_metric_T` | nan |
| `gradient_strength_constraint_met` | False |
| `gradient_strength_constraint_field_metric_T` | nan |
| `gradient_strength_constraint_allowed_field_metric_T` | nan |
| `cross_gradient_constraint_met` | False |
| `cross_gradient_constraint_field_metric_T` | nan |
| `cross_gradient_constraint_allowed_field_metric_T` | nan |
| `target_error_auto_retry_count` | 0 |
| `target_error_auto_retry_selected_rerun` | 0 |
| `target_error_auto_retry_selected_violation_ratio` | nan |
| `dsv_constraint_met` | True |
| `dsv_constraint_metric` | norm |
| `dsv_constraint_weighting` | uniform |
| `dsv_constraint_residual_statistics_scope` | weighted_physical_field |
| `dsv_constraint_relative_residual_percent` | 3.06122 |
| `dsv_constraint_allowed_residual_norm_T` | 1.78326e-06 |
| `dsv_constraint_field_metric_T` | 1.36473e-06 |
| `dsv_constraint_allowed_field_metric_T` | 1.78326e-06 |
| `dsv_constraint_allowed_with_acceptance_field_metric_T` | 1.88326e-06 |
| `dsv_constraint_std_T` | 8.51297e-08 |
| `dsv_constraint_allowed_std_T` | nan |
| `dsv_constraint_rms_residual_T` | 8.51298e-08 |
| `suppression_constraint_enabled` | False |
| `suppression_constraint_met` | False |
| `suppression_constraint_relative_residual_percent` | nan |
| `suppression_constraint_allowed_residual_norm_T` | nan |
| `suppression_constraint_rms_residual_T` | nan |
| `suppression_target_enabled` | False |
| `suppression_target_component` |  |
| `suppression_surface_weighting` |  |
| `suppression_target_sample_count` | 0 |
| `suppression_target_weight_mean` | nan |
| `suppression_target_rms_residual_T` | nan |
| `suppression_target_peak_abs_residual_T` | nan |
| `suppression_target_weighted_rms_residual_T` | nan |
| `suppression_field_rms_T` | nan |
| `suppression_field_rms_limit_T` | nan |
| `suppression_field_peak_T` | nan |
| `suppression_field_peak_limit_T` | nan |
| `suppression_clearance_status` | not_applicable |
| `suppression_clearance_generator` |  |
| `suppression_clearance_action` |  |
| `suppression_clearance_requested_m` | nan |
| `suppression_clearance_min_allowed_m` | nan |
| `suppression_clearance_min_m` | nan |
| `suppression_clearance_p05_m` | nan |
| `suppression_clearance_median_m` | nan |
| `suppression_clearance_max_m` | nan |
| `suppression_clearance_input_vertex_count` | 0 |
| `suppression_clearance_output_vertex_count` | 0 |
| `suppression_clearance_output_face_count` | 0 |
| `suppression_clearance_dropped_face_count` | 0 |
| `suppression_clearance_violation_count` | 0 |
| `suppression_clearance_warning` |  |
| `combined_weighted_residual_norm_T` | 1.36473e-06 |
| `constrained_solver_backend` | cvxpy_research |
| `constrained_solver_name` | CLARABEL |
| `constrained_solver_status` | optimal |
| `constrained_solver_contract_met` | True |
| `research_objective` | power |
| `sheet_power_W` | 0.310749 |
| `energy_J` | None |
| `force_N` | 0, 0, 0 |
| `torque_Nm` | 5.02929e-14, 1.45077e-13, 0 |
| `torque_origin_m` | 0, 0, 0 |
| `b0_T` | 0, 0, 3 |
| `force_model` | uniform_B0_total_closed_current_force_vanishes |
| `research_objective_scales` | {'power': 1561331.2098434654} |
| `research_tolerance_scale` | 1 |
| `research_scenario_count` | 0 |
| `max_surface_current_density_A_per_m` | 450.055 |
| `constrained_solver_physical_constraints_met` | True |
| `constrained_solver_diagnostic_result` | False |
| `constrained_solver_diagnostic_reason` |  |
| `constrained_solver_failed_constraints` |  |
| `constrained_solver_fallback_reason` |  |
| `stream_function_smoothness_enabled` | False |
| `stream_function_smoothness_factor` | nan |
| `stream_function_basis` |  |
| `stream_function_spectral_active` | False |
| `stream_function_spectral_unknown_count_before` | 0 |
| `stream_function_spectral_unknown_count_after` | 0 |
| `stream_function_spectral_reduction_factor` | nan |
| `stream_function_spectral_cutoff_length_m` | nan |
| `stream_function_spectral_min_retained_wavelength_m` | nan |
| `sensitivity_target_point_count` | 257 |
| `sensitivity_mesh_vertex_count` | 416 |
| `sensitivity_unknown_count` | 416 |
| `sensitivity_matrix_part_count` | 1 |
| `sensitivity_matrix_bytes` | 2565888 |
| `sensitivity_matrix_MiB` | 2.44702 |
| `sensitivity_matrix_shapes` | 3x257x416 |
| `execution_time_s` | 696.415 |
| `regularization_knee_type` | fixed |
| `regularization_residual_log_span` | nan |
| `regularization_resistance_log_span` | nan |
| `regularization_selected_residual_position` | nan |
| `regularization_selected_resistance_position` | nan |
| `selected_target_residual_norm_T_per_A` | 1.36473e-06 |
| `selected_resistance_seminorm_ohm_A` | nan |
| `gradient_slice_maps_enabled` | False |
| `gradient_slice_maps_status` | not_enabled |
| `concomitant_sample_count` | 0 |
| `concomitant_main_field_T` | nan |
| `concomitant_b0_direction_x` | nan |
| `concomitant_b0_direction_y` | nan |
| `concomitant_b0_direction_z` | nan |
| `concomitant_gradient_x_T_per_m` | nan |
| `concomitant_gradient_y_T_per_m` | nan |
| `concomitant_gradient_z_T_per_m` | nan |
| `concomitant_rms_T` | nan |
| `concomitant_p95_abs_T` | nan |
| `concomitant_max_abs_T` | nan |
| `concomitant_rms_ppm_of_B0` | nan |
| `concomitant_p95_abs_ppm_of_B0` | nan |
| `concomitant_max_abs_ppm_of_B0` | nan |
| `concomitant_rms_percent_of_target_peak` | nan |
| `concomitant_max_abs_percent_of_target_peak` | nan |
| `concomitant_model` | linear_gradient_small_field_magnitude |
| `concomitant_assumption` | main field defines local z; fitted scalar gradient is B0-parallel |
| `concomitant_gradient_source` | not_applicable_for_design_context |
| `current_density_current_A` | 1.75156 |
| `current_density_conductor_width_m` | 0.001 |
| `current_density_conductor_height_m` | 0.001 |
| `current_density_conductor_area_m2` | 1e-06 |
| `current_density_A_per_m2` | 1.75156e+06 |
| `current_density_A_per_mm2` | 1.75156 |
| `current_density_class` | continuous_candidate |
| `current_density_assumption` | rectangular conductor cross section; no thermal duty-cycle model |
| `thermal_screening_status` | not_evaluated |
| `thermal_screening_included` | False |
| `thermal_screening_assumption` | no duty cycle, cooling, temperature-rise, or conductor insulation model evaluated |
| `engineering_readiness_status` | screening_only |
| `finished_engineering_design_ready` | False |
| `magnetostatic_status` | FAIL |
| `layout_status` | FAIL |
| `engineering_checks_not_included` | thermal; gradient-driver voltage/current margin; slew-rate validation; PNS; acoustic response; Lorentz force and torque; eddy-current coupling; cryostat or nearby-conductor heating; mechanical stress; terminal routing validation |
| `layout_gradient_efficiency_mT_per_m_per_A` | nan |
| `layout_field_efficiency_mT_per_A` | nan |
| `layout_needed_current_A` | 1.75156 |
| `layout_mean_rel_error_percent` | 5.50274 |
| `layout_max_rel_error_percent` | 9.16898 |
| `layout_fit_sample_count` | 0 |
| `unconnected_contours_gradient_efficiency_mT_per_m_per_A` | nan |
| `unconnected_contours_field_efficiency_mT_per_A` | nan |
| `unconnected_contours_needed_current_A` | nan |
| `unconnected_contours_mean_rel_error_percent` | 3.80536 |
| `unconnected_contours_max_rel_error_percent` | 7.5968 |
| `unconnected_contours_fit_sample_count` | 0 |
| `stream_function_gradient_efficiency_mT_per_m_per_A` | nan |
| `stream_function_field_efficiency_mT_per_A` | nan |
| `stream_function_needed_current_A` | nan |
| `stream_function_mean_rel_error_percent` | nan |
| `stream_function_max_rel_error_percent` | nan |
| `stream_function_fit_sample_count` | 0 |
| `symmetry_diagnostics_available` | False |
| `symmetry_reduction_active` | False |
| `symmetry_reduction_factor` | nan |
| `symmetry_reduction_unknown_count_before` | 0 |
| `symmetry_reduction_unknown_count_after` | 0 |
| `symmetry_reduction_reason` |  |
| `contour_symmetry_pair_count` | 0 |
| `contour_symmetry_failed_pair_count` | 0 |
| `symmetry_warning_count` | 0 |
| `symmetry_failure_count` | 0 |
| `coil_inductance_matrix_part_count` | 1 |
| `coil_inductance_self_part1_H` | 0.000114962 |
| `max_rel_error_layout_vs_target_percent` | 9.16898 |
| `mean_rel_error_layout_vs_target_percent` | 5.50274 |
| `max_rel_error_unconnected_contours_vs_target_percent` | 7.5968 |
| `mean_rel_error_unconnected_contours_vs_target_percent` | 3.80536 |
| `max_rel_error_layout_vs_stream_function_field_percent` | 9.62559 |
| `mean_rel_error_layout_vs_stream_function_field_percent` | 5.74849 |
| `max_rel_error_unconnected_contours_vs_stream_function_field_percent` | 8.50879 |
| `mean_rel_error_unconnected_contours_vs_stream_function_field_percent` | 3.95154 |

## Regularization Selection

| Quantity | Value |
|---|---:|
| `selection_method` | research_convex |
| `candidate_solver` |  |
| `selected_factor` | 0 |
| `selected_lambda` | 0 |
| `selected_index` | -1 |
| `candidate_count` | 0 |
| `valid_candidate_count` | 0 |
| `fallback` | False |
| `fallback_reason` |  |
| `knee_type` | fixed |
| `residual_log_span` | nan |
| `regularization_log_span` | nan |
| `selected_residual_position` | nan |
| `selected_regularization_position` | nan |
| `selected_curvature` | nan |
| `warnings` |  |

## DSV Field Error

| Quantity | Value |
|---|---:|
| `max_rel_error_layout_vs_target [%]` | 9.16898 |
| `mean_rel_error_layout_vs_target [%]` | 5.50274 |
| `max_rel_error_unconnected_contours_vs_target [%]` | 7.5968 |
| `mean_rel_error_unconnected_contours_vs_target [%]` | 3.80536 |
| `max_rel_error_layout_vs_stream_function_field [%]` | 9.62559 |
| `mean_rel_error_layout_vs_stream_function_field [%]` | 5.74849 |
| `max_rel_error_unconnected_contours_vs_stream_function_field [%]` | 8.50879 |
| `mean_rel_error_unconnected_contours_vs_stream_function_field [%]` | 3.95154 |

## Concomitant Field Report

Not applicable for design_context=mr_shim.

| Quantity | Value |
|---|---:|
| `concomitant_model` | linear_gradient_small_field_magnitude |
| `concomitant_assumption` | main field defines local z; fitted scalar gradient is B0-parallel |
| `concomitant_gradient_source` | not_applicable_for_design_context |
| `concomitant_main_field_T` | nan |
| `concomitant_b0_direction_x` | nan |
| `concomitant_b0_direction_y` | nan |
| `concomitant_b0_direction_z` | nan |
| `concomitant_gradient_x_T_per_m` | nan |
| `concomitant_gradient_y_T_per_m` | nan |
| `concomitant_gradient_z_T_per_m` | nan |
| `concomitant_sample_count` | 0 |
| `concomitant_rms_T` | nan |
| `concomitant_p95_abs_T` | nan |
| `concomitant_max_abs_T` | nan |
| `concomitant_rms_ppm_of_B0` | nan |
| `concomitant_max_abs_ppm_of_B0` | nan |
| `concomitant_rms_percent_of_target_peak` | nan |
| `concomitant_max_abs_percent_of_target_peak` | nan |

## Current-Density Report

Uses the configured conductor cross section and fitted layout current. It is not a thermal or duty-cycle calculation.

| Quantity | Value |
|---|---:|
| `current_density_current_A` | 1.75156 |
| `current_density_conductor_width_m` | 0.001 |
| `current_density_conductor_height_m` | 0.001 |
| `current_density_conductor_area_m2` | 1e-06 |
| `current_density_A_per_m2` | 1.75156e+06 |
| `current_density_A_per_mm2` | 1.75156 |
| `current_density_class` | continuous_candidate |
| `current_density_assumption` | rectangular conductor cross section; no thermal duty-cycle model |

## Inductance Matrix

Rows and columns are independent coil parts. Off-diagonal entries are mutual inductances; signs include the actual current/path orientation.

| `row` | `column` | `type` | `inductance_H` |
| --- | --- | --- | --- |
| 1 | 1 | self | 0.000114962 |

## Timing

| Quantity | Value |
|---|---:|
| `start` | 0.000 s; elapsed 0.000 s |
| `loaded meshes` | 0.007 s; elapsed 0.007 s |
| `prepared coil meshes` | 0.022 s; elapsed 0.029 s |
| `defined target field` | 0.004 s; elapsed 0.033 s |
| `built one-ring mesh neighborhoods` | 0.059 s; elapsed 0.092 s |
| `built stream-function basis` | 0.106 s; elapsed 0.199 s |
| `calculated sensitivity matrix` | 0.287 s; elapsed 0.486 s |
| `calculated resistance matrix` | 0.427 s; elapsed 0.913 s |
| `optimized stream function` | 0.685 s; elapsed 1.598 s |
| `calculated potential levels` | 0.430 s; elapsed 2.027 s |
| `extracted contours` | 0.090 s; elapsed 2.118 s |
| `filtered loop significance` | 0.000 s; elapsed 2.118 s |
| `regularized contour paths` | 31.371 s; elapsed 33.489 s |
| `validated contourability` | 0.000 s; elapsed 33.489 s |
| `processed contour sparsification, pruning, and retained-contour consolidation` | 0.726 s; elapsed 34.215 s |
| `calculated contour distances` | 0.000 s; elapsed 34.215 s |
| `grouped contour topology` | 6.046 s; elapsed 40.260 s |
| `interconnected within loop groups` | 0.911 s; elapsed 41.171 s |
| `interconnected among loop groups` | 389.728 s; elapsed 430.899 s |
| `shifted return paths` | 8.296 s; elapsed 439.195 s |
| `cleaned wire paths` | 0.803 s; elapsed 439.998 s |
| `realized fabrication centerlines` | 37.561 s; elapsed 477.559 s |
| `selected joint group routes` | 146.255 s; elapsed 623.814 s |
| `finalized swept conductor meshes` | 56.056 s; elapsed 679.870 s |
| `calculated inductance and resistance` | 14.437 s; elapsed 694.307 s |
| `evaluated field errors` | 2.108 s; elapsed 696.415 s |

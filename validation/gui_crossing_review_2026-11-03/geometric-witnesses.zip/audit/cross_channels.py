"""Audit packaged multi-channel systems in their common design/world coordinates (SI)."""
from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path

import numpy as np

from coilgen.application.templates import template_assembly
from coilgen.geometry_kernels import triangle_pair_distances
from coilgen.manufacturing import _polygon_centroid, _triangulate_sweep_laterals
from coilgen.models import Mesh
from coilgen.research.fabrication import _inside_closed_mesh
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = Path('C:/Users/Flipp/AppData/Local/Temp/coilgen-winding-quality-20261103/gallery-browser/users/local/embedded-runs')
EPS = 1e-10


def radial_bounds(vertices, faces):
    # Min and max distance from the world z axis including triangle interiors.
    xy = vertices[faces, :2]
    end = np.roll(xy, -1, axis=1)
    d = end - xy
    norm = (d * d).sum(axis=2)
    parameter = np.divide(-(xy * d).sum(axis=2), norm, where=norm > 0, out=np.zeros_like(norm)).clip(0, 1)
    closest = xy + d * parameter[:, :, None]
    signed = xy[:, :, 0] * end[:, :, 1] - xy[:, :, 1] * end[:, :, 0]
    projected_inside = (np.all(signed > 0, axis=1) | np.all(signed < 0, axis=1))
    rmin = 0.0 if np.any(projected_inside) else float(np.min(np.linalg.norm(closest, axis=2)))
    return rmin, float(np.max(np.linalg.norm(vertices[:, :2], axis=1)))


def read_meshes(directory, expected, geometry):
    data = json.loads((directory / 'result.json').read_bytes())
    assert data['project_model_fingerprint'] == expected
    sources = []
    with np.load(directory / 'scientific_result.npz', allow_pickle=False) as a:
        for i, path in enumerate(data['fabrication']['paths']):
            prefix = f'review_conductor_{i}_frame_'
            p, normal, across, profile = (a[prefix + k] for k in ('points_m', 'normals', 'transverse', 'cross_section_m'))
            assert bool(a[prefix + 'closed']) and np.isfinite(p).all()
            ref = np.zeros(2) if path['diagnostics'].get('conductor_path_reference') == 'profile_origin' else _polygon_centroid(profile)
            v = (p[:, None, :] + (profile[:, 0]-ref[0])[None, :, None]*across[:, None, :] + (profile[:, 1]-ref[1])[None, :, None]*normal[:, None, :]).reshape(-1,3)
            saved = f'swept_{path["part_index"]-1}_0_'
            equal = v.shape == a[saved + 'vertices_m'].shape and np.allclose(v, a[saved + 'vertices_m'], rtol=0, atol=1e-12)
            if equal or geometry == 'pipeline':
                v, f = a[saved + 'vertices_m'], a[saved + 'faces']
            else:
                f = np.asarray(_triangulate_sweep_laterals(v, len(p), len(profile), closed=True, optimize_diagonals=True)[0])
            if geometry == 'strict_review':
                from geometry_audit import stl_mesh
                stls = list((directory/'fabrication').glob(path['body_id']+'*fabrication.stl'))
                if len(stls)!=1:
                    raise ValueError(f'Need unique strict review STL for {path["body_id"]} in {directory}')
                sv,sf=stl_mesh(stls[0])
                assert len(f)==len(sf)==int(path['diagnostics']['face_count'])
                # Verify all exported vertices against the stored production frames (STL decimal rounding).
                assert max(cKDTree(v).query(sv)[0].max(),cKDTree(sv).query(v)[0].max()) < 1e-8
                v,f=sv,sf
            sources.append((path['body_id'], Mesh(v, f), v.min(axis=0), v.max(axis=0), radial_bounds(v, f), bool(equal)))
    return sources, data['request_sha256']


def narrow(mesh1, mesh2):
    a, b = mesh1.vertices[mesh1.faces], mesh2.vertices[mesh2.faces]
    low_a, high_a = a.min(axis=1), a.max(axis=1)
    low_b, high_b = b.min(axis=1), b.max(axis=1)
    ca, cb = (low_a + high_a)/2, (low_b + high_b)/2
    ra, rb = np.linalg.norm(high_a-low_a,axis=1)/2, np.linalg.norm(high_b-low_b,axis=1)/2
    buckets = np.floor(np.log2(np.maximum(rb,1e-14))).astype(int)
    count = 0
    for group in np.unique(buckets):
        ids = np.flatnonzero(buckets == group)
        tree = cKDTree(cb[ids])
        for first in range(0,len(a),256):
            indices = np.arange(first,min(first+256,len(a)))
            hits = tree.query_ball_point(ca[indices],ra[indices]+rb[ids].max()+EPS+1e-14)
            lens = np.array([len(h) for h in hits])
            if not lens.any():
                continue
            ia, ib = np.repeat(indices,lens), ids[np.concatenate(hits).astype(int)]
            mask = np.all((low_a[ia] <= high_b[ib]+EPS+1e-14) & (low_b[ib] <= high_a[ia]+EPS+1e-14),axis=1)
            ia,ib = ia[mask],ib[mask]
            if not len(ia):
                continue
            dist = triangle_pair_distances(a[ia],b[ib]).values_m
            assert np.isfinite(dist).all()
            count += len(ia)
            h = np.flatnonzero(dist <= EPS)
            if len(h):
                k=h[0]
                return dict(intersects=True, method='triangle_contact', triangle_indices=[int(ia[k]),int(ib[k])], distance_m=float(dist[k]), triangles_m=[a[ia[k]].tolist(), b[ib[k]].tolist()], tested=count)
    inside = _inside_closed_mesh(mesh1.vertices[0],mesh2) or _inside_closed_mesh(mesh2.vertices[0],mesh1)
    return dict(intersects=inside, method='triangle_distance_and_containment',tested=count)


def compare(first,second):
    name_a,mesh_a,low_a,high_a,r_a,_=first
    name_b,mesh_b,low_b,high_b,r_b,_=second
    box = np.linalg.norm(np.maximum(0,np.maximum(low_a-high_b,low_b-high_a)))
    cylindrical = max(0.0,r_a[0]-r_b[1],r_b[0]-r_a[1])
    gap = max(box,cylindrical)
    if gap > EPS:
        return dict(intersects=False, method='disjoint_cartesian_boxes' if box>=cylindrical else 'disjoint_cylindrical_shells', gap_lower_bound_m=float(gap))
    return narrow(mesh_a,mesh_b)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('system')
    ap.add_argument('--run',nargs='+', type=Path)
    ap.add_argument('--run-map',type=Path)
    ap.add_argument('--geometry',choices=['pipeline','strict_review'],default='strict_review')
    args=ap.parse_args()
    channels=template_assembly(args.system).channels
    if args.run_map is not None:
        run_map=json.loads(args.run_map.read_bytes())
        runs=[Path(run_map[f'{args.system}__{i}']) for i in range(len(channels))]
    elif args.run is None:
        rows=[r for r in csv.DictReader((ROOT/'validation/gui_winding_quality_2026-11-03/full-gallery.csv').open(encoding='utf-8-sig')) if r['template']==args.system]
        cache={j['request_sha256']:path.parent for path in ARCHIVE.glob('*/result.json') if (j:=json.loads(path.read_bytes())).get('request_sha256')}
        runs=[cache[r['request_sha256']] for r in sorted(rows,key=lambda r:int(r['channel_index']))]
    else:
        runs=args.run
    assert len(runs)==len(channels)
    results=[]
    sources=[]
    by_channel=[]
    for c,folder in zip(channels,runs):
        if not (folder/'result.json').is_file() and (folder/'run'/'result.json').is_file():
            folder=folder/'run'
        meshes,request=read_meshes(folder,c.project.model_fingerprint,args.geometry)
        sources.append(dict(channel=c.name,model_fingerprint=c.project.model_fingerprint,request=request,match_pipeline_mesh=[m[-1] for m in meshes]))
        by_channel.append((c.name,meshes))
    for (ca,first),(cb,second) in itertools.combinations(by_channel,2):
        for a,b in itertools.product(first,second):
            results.append(dict(channels=[ca,cb],bodies=[a[0],b[0]],**compare(a,b)))
    result=dict(system=args.system,evaluated=args.geometry,surface_contact_tolerance_m=EPS,channels=sources,cross_channel_body_pairs=results)
    out=Path(__file__).with_name(args.system+'_'+args.geometry+('_fresh' if args.run_map or args.run else '_archived')+'_interchannel.json')
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    from collections import Counter
    print(args.system, len(results),Counter(r['method'] for r in results), sum(r['intersects'] for r in results), min((r['gap_lower_bound_m'] for r in results if 'gap_lower_bound_m' in r),default=None))


if __name__=='__main__':
    main()

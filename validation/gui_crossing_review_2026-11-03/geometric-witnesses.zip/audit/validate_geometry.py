"""Analytic, differential, broad-phase completeness, and saved-route alias checks."""
import itertools
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from coilgen.geometry_kernels import segment_pair_distances, triangle_pair_distances
from geometry_audit import audit_paths, audit_meshes, audit_saved, candidates, nearest, triangle_intersections


def path(points):
    return np.asarray(points,dtype=float)


def verify():
    a=path([[0,0,0],[2,0,0]])
    b=path([[1,-1,0],[1,1,0]])
    assert audit_paths(dict(a=a,b=b))["centerline_cross_path_pairs"]==1
    assert audit_paths(dict(a=a,b=b+np.array([0,0,1e-4])))["centerline_cross_path_pairs"]==0
    assert audit_paths(dict(a=a,b=b+np.array([0,0,1e-4])),clearance_m=2e-4)["remote_envelope_pairs"]==1
    assert audit_paths(dict(a=[[0,0,0],[1,1,0],[0,1,0],[1,0,0]]))["centerline_contact_pairs"]==1
    assert audit_paths(dict(a=[[0,0,0],[1,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,0]]))["centerline_contact_pairs"]==0
    assert audit_paths(dict(a=[[0,0,0],[1,0,0],[0.2,0,0]]))["adjacent_retraces"]==1
    micro=audit_paths(dict(a=[[0,0,0],[1,0,0],[1+5e-10,0,0],[2,0,0]]))
    assert micro["centerline_contact_pairs"]==0 and micro["centerline_local_join_pairs"]==1
    assert audit_paths(dict(a=a,b=a+.25*np.array([1,0,0])))["centerline_cross_path_pairs"]==1
    tri=path([[0,0,0],[1,0,0],[0,1,0]])
    cross=path([[.3,.3,-1],[.5,.3,1],[.1,.3,1]])
    one=np.array([[0,1,2]])
    cases=[(cross,True),(tri.copy(),True),(tri+np.array([.8,.8,0]),False),
           (tri+np.array([1,0,0]),True),(tri+np.array([0,0,1e-6]),False)]
    for other,expected in cases:
        assert triangle_intersections(tri[None],other[None])[0]==expected
        checks=audit_meshes({"a":(tri,one),"b":(other,one)})
        assert checks["cross_body_triangle_pairs"]==int(expected)
        assert checks["penetrating_triangle_pairs"]==int(other is cross)
    square = path([[0,0,0],[1,0,0],[0,1,0],[1,1,0]])
    assert audit_meshes({"a":(square,np.array([[0,1,2],[1,3,2]]))})["contacting_triangle_pairs"]==0
    rng=np.random.default_rng(1147)
    a,b=rng.normal(size=(2,3000,2,3))
    d,s,t=nearest(a[:,0],a[:,1],b[:,0],b[:,1])
    dref=segment_pair_distances(a,b,backend="numpy").values_m
    np.testing.assert_allclose(d,dref,atol=1e-12)
    np.testing.assert_allclose(d,np.linalg.norm(a[:,0]+s[:,None]*(a[:,1]-a[:,0])-b[:,0]-t[:,None]*(b[:,1]-b[:,0]),axis=1),atol=1e-12)
    a,b=rng.normal(size=(2,2000,3,3))
    for coplanar in (False,True):
        if coplanar:
            a[:,:,2] = b[:,:,2] = 0
        direct=triangle_intersections(a,b)
        reference=triangle_pair_distances(a,b,backend="numpy").values_m<=1e-12
        np.testing.assert_array_equal(direct,reference)
    center=rng.random(size=(230,3))
    extent=10**rng.uniform(-4,.25,size=(230,3))
    low,high=center-extent,center+extent
    for tol in (0,1e-4,.1):
        got=[(i,j) for aa,bb in candidates(low,high,tol) for i,j in zip(aa,bb)]
        pair=list(itertools.combinations(range(len(low)),2))
        want={(i,j) for i,j in pair if np.all(low[i]<=high[j]+tol) and np.all(low[j]<=high[i]+tol)}
        assert len(got)==len(set(got)) and set(got)==want
    with TemporaryDirectory(prefix="coilgen-crossing-fixture-") as scratch:
        output=Path(scratch)/"alias_fixture.npz"
        np.savez(output,fabrication_0_0_points_m=a[0],fabrication_0_points_m=a[0],fabrication_1_points_m=b[0])
        evaluated=audit_saved(output)
        assert evaluated["route"]["path_count"]==0 and evaluated["fabrication"]["path_count"]==2
    print("Passed analytic cases, 3,000 segment and 4,000 triangle differential checks, "
          "complete all-pairs broad-phase comparisons, and saved aliases.")


if __name__=="__main__":
    verify()

# CoilGen Design Report

Generated with **CoilGen2**. Created and maintained by Philipp Amrein — MRI hardware engineer.

Original CoilGen reference: [Amrein P, Jia F, Zaitsev M, Littin S. CoilGen: Open-source MR coil layout generator. Magnetic Resonance in Medicine. 2022;88(3):1465–1479.](https://doi.org/10.1002/mrm.29294)

Execution status: **completed**
Engineering acceptance: **FAIL** (reported checks only)
Unassessed engineering checks and construction release are excluded from this status.
Design context: **mr_gradient**

## Failures

- Route-quality diagnostics report at least one failed coil part.
- Manufacturing diagnostics report invalid swept-body geometry.

## Warnings

- [WARNING] layout_terminal_strategy: Connected-layout routing has no terminal handling strategy. Suggestion: Set pads, wire_stubs, or waived when the result is intended for manufacturing review.
- [WARNING] layout_terminal_strategy: Swept-body export is enabled without explicit terminal handling. Suggestion: Define terminal pads/wire stubs or mark terminal handling as waived.
- [WARNING] conductor_mounting_mode: Manufacturing conductor centerline is offset from the electromagnetic wire path. Suggestion: Use centered mode for exact field-evaluation consistency, or re-evaluate fields with the shifted manufacturing path.

## Magnetostatic Feasibility

| Quantity | Value |
|---|---:|
| `overall_status` | FAIL |
| `target_point_count` | 257 |
| `dsv_target_point_count` | 257 |
| `layout_gradient_efficiency_mT_per_m_per_A` | 1.63621 |
| `layout_needed_current_A` | 12.2233 |
| `layout_mean_rel_error_percent` | 0.59685 |
| `layout_max_rel_error_percent` | 4.09598 |
| `shim_layout_residual_rms_T` |  |
| `shim_layout_residual_max_abs_T` |  |
| `target_error_constraint_met` | True |
| `dsv_constraint_met` | True |
| `constrained_solver_contract_met` | True |
| `constrained_solver_physical_constraints_met` | True |
| `constrained_solver_diagnostic_result` | False |
| `constrained_solver_failed_constraints` |  |

## Layout Feasibility

| Quantity | Value |
|---|---:|
| `layout_status` | FAIL |
| `route_statuses` | fail |
| `contour_count` | 32 |
| `topological_group_count` | 2 |
| `min_contour_distance_m` | nan |
| `unconnected_contours_min_wire_distance_m` | nan |
| `min_wire_wire_distance_m` | 6.96272e-10 |
| `wire_clearance_failure_threshold_m` | 0 |
| `wire_clearance_failure_count` | 0 |
| `current_density_class` | continuous_candidate |
| `finished_engineering_design_ready` | False |

## Engineering Checks Not Included

| Quantity | Value |
|---|---:|
| `engineering_readiness_status` | screening_only |
| `finished_engineering_design_ready` | False |
| `magnetostatic_status` | FAIL |
| `layout_status` | FAIL |
| `engineering_checks_not_included` | thermal; gradient-driver voltage/current margin; slew-rate validation; PNS; acoustic response; Lorentz force and torque; eddy-current coupling; cryostat or nearby-conductor heating; mechanical stress; terminal routing validation |

## Suppression-Clearance Report

Checks generated zero-field suppression target points against the source mesh used for clearance validation.

| Quantity | Value |
|---|---:|
| `suppression_clearance_status` | not_applicable |
| `suppression_clearance_generator` |  |
| `suppression_clearance_action` |  |
| `suppression_clearance_requested_m` | nan |
| `suppression_clearance_min_allowed_m` | nan |
| `suppression_clearance_min_m` | nan |
| `suppression_clearance_p05_m` | nan |
| `suppression_clearance_median_m` | nan |
| `suppression_clearance_max_m` | nan |
| `suppression_clearance_input_vertex_count` | 0 |
| `suppression_clearance_output_vertex_count` | 0 |
| `suppression_clearance_output_face_count` | 0 |
| `suppression_clearance_dropped_face_count` | 0 |
| `suppression_clearance_violation_count` | 0 |
| `suppression_clearance_warning` |  |

## Numerical Summary

| Quantity | Value |
|---|---:|
| `report_schema_version` | coilgen-report-v1 |
| `execution_status` | completed |
| `engineering_acceptance_status` | FAIL |
| `engineering_status` | FAIL |
| `engineering_acceptance_scope` | Reported checks only; unassessed checks and construction release are excluded. |
| `quality_status` | FAIL |
| `quality_failures` | Route-quality diagnostics report at least one failed coil part.; Manufacturing diagnostics report invalid swept-body geometry. |
| `quality_warnings` |  |
| `first_failing_check` | Route-quality diagnostics report at least one failed coil part. |
| `first_failure` | Route-quality diagnostics report at least one failed coil part. |
| `target_error_constraint_status` | PASS |
| `dsv_constraint_status` | PASS |
| `suppression_constraint_status` | inactive |
| `linearity_rms_constraint_status` | inactive |
| `linearity_peak_constraint_status` | inactive |
| `gradient_strength_constraint_status` | inactive |
| `cross_gradient_constraint_status` | inactive |
| `shield_gradient_opposition_constraint_status` | inactive |
| `software_name` | CoilGen2 |
| `software_creator` | Philipp Amrein |
| `software_maintainer` | Philipp Amrein |
| `software_creator_role` | MRI hardware engineer |
| `software_repository` | https://github.com/Philipp-MR/Coilgen2 |
| `software_original_coilgen_doi` | 10.1002/mrm.29294 |
| `problem_schema_version` |  |
| `design_context` | mr_gradient |
| `design_context_is_mr` | True |
| `design_context_evaluation_features` | concomitant_field, electrical, field_error, gradient_fit, manufacturing, routing, target_mode_fit |
| `target_field_component` | Bz |
| `field_evaluation_current_source` | stream_function |
| `routing_field_acceptance_policies` |  |
| `routing_absolute_field_contract_status` | not_checked |
| `routing_absolute_field_contract_failed_part_count` | 0 |
| `routing_absolute_field_contract_failure_reasons` |  |
| `routing_clearance_target_m` | 0.00307843 |
| `routing_source_contour_clearance_m` | 0 |
| `routing_physical_minimum_centerline_distance_m` | nan |
| `routing_physical_clearance_lower_bound_m` | nan |
| `field_source_label` | Bz target, stream_function current |
| `layout_terminal_strategy` | undefined |
| `layout_terminal_pad_count` | 0 |
| `layout_terminal_exit_count` | 0 |
| `layout_keepout_region_count` | 0 |
| `layout_manufacturing_intent` | Independent cylindrical gradient channel; inter-channel clearance, feeds, stray field and drive qualification remain unresolved. |
| `part_count` | 1 |
| `target_point_count` | 257 |
| `dsv_target_point_count` | 257 |
| `suppression_point_count` | 0 |
| `target_field_units` | T |
| `field_display_units` | T |
| `proton_frequency_Hz_per_T` | 4.25775e+07 |
| `contour_count` | 32 |
| `nominal_contour_geometry_count` | 32 |
| `physical_turn_count` | 32 |
| `contour_sparsification_mode` | off |
| `contour_sparsification_accepted_merge_count` | 0 |
| `contour_sparsification_completed_pass_count` | 0 |
| `contour_sparsification_achieved_max_turn_multiplicity` | 0 |
| `contour_sparsification_global_rms_field_error_percent` | 0 |
| `contour_sparsification_global_peak_field_error_percent` | 0 |
| `contour_sparsification_merge_rms_field_error_percent` | 0 |
| `contour_sparsification_merge_peak_field_error_percent` | 0 |
| `contour_sparsification_residual_budget_enabled` | False |
| `contour_sparsification_residual_baseline_metric_T` | nan |
| `contour_sparsification_residual_allowed_metric_T` | nan |
| `contour_sparsification_merge_selected_residual_metric_T` | nan |
| `contour_sparsification_merge_residual_metric_change_T` | nan |
| `contour_sparsification_pruning_mode` | off |
| `contour_sparsification_pruning_removed_geometry_count` | 0 |
| `contour_sparsification_pruning_removed_turn_count` | 0 |
| `contour_sparsification_pruning_baseline_metric_T` | nan |
| `contour_sparsification_pruning_selected_metric_T` | nan |
| `contour_sparsification_pruning_metric_change_T` | nan |
| `contour_sparsification_pruning_incremental_rms_field_error_percent` | 0 |
| `contour_sparsification_pruning_incremental_peak_field_error_percent` | 0 |
| `topological_group_count` | 2 |
| `effective_contour_levels` | 16 |
| `contour_discretization_method` | level_count |
| `max_wire_current_A` | 0 |
| `min_wire_distance_m` | 0 |
| `engineering_max_contour_step_A` | 0 |
| `engineering_required_contour_step_A` | nan |
| `engineering_current_limit_feasible` | True |
| `surface_current_density_limit_A_per_m` | 0 |
| `surface_current_density_limit_met` | True |
| `surface_current_density_max_A_per_m` | 2505.56 |
| `surface_current_density_p99_A_per_m` | 2505.55 |
| `target_gradient_normalization_method` | linear_fit |
| `target_gradient_axis` | z |
| `target_gradient_requested_T_per_m` | 0.02 |
| `target_gradient_hardware_effective_T_per_m` | 0.02 |
| `gradient_hardware_feasible` | True |
| `gradient_hardware_scale_factor` | nan |
| `linearity_enabled` | False |
| `linearity_applicable` | True |
| `linearity_status` | not_checked |
| `linearity_met` | True |
| `linearity_failure_reasons` |  |
| `linearity_region` | dsv |
| `linearity_normalization` | requested_gradient_times_radius |
| `linearity_fit_offset` | True |
| `linearity_reference_radius_m` | 0.02 |
| `linearity_reference_scale_T` | 0.0004 |
| `linearity_requested_gradient_T_per_m` | 0.02 |
| `linearity_desired_gradient_T_per_m` | 0.02 |
| `linearity_achieved_gradient_T_per_m` | 0.0191327 |
| `linearity_gradient_strength_error_percent` | 4.33646 |
| `linearity_gradient_strength_tolerance_percent` | 0 |
| `linearity_gradient_strength_met` | True |
| `linearity_gradient_strength_status` | not_checked |
| `linearity_cross_gradient_T_per_m` | 2.92851e-06 |
| `linearity_cross_gradient_percent` | 0.0146425 |
| `linearity_cross_gradient_tolerance_percent` | 0 |
| `linearity_cross_gradient_met` | True |
| `linearity_cross_gradient_status` | not_checked |
| `linearity_rms_residual_T` | 3.17705e-06 |
| `linearity_p95_abs_residual_T` | 5.34075e-06 |
| `linearity_peak_abs_residual_T` | 1.56469e-05 |
| `linearity_rms_percent` | 0.794263 |
| `linearity_p95_percent` | 1.33519 |
| `linearity_peak_percent` | 3.91173 |
| `linearity_rms_tolerance_percent` | 0 |
| `linearity_peak_tolerance_percent` | 0 |
| `linearity_rms_met` | True |
| `linearity_peak_met` | True |
| `linearity_rms_status` | not_checked |
| `linearity_peak_status` | not_checked |
| `linearity_sample_count` | 257 |
| `contourability_checked` | False |
| `contourability_ok` | True |
| `contourability_repaired` | False |
| `contourability_reason` |  |
| `contourability_requested_levels` | 16 |
| `contourability_selected_levels` | 16 |
| `contourability_field_rms_error_percent` | nan |
| `contourability_field_mean_abs_error_percent` | nan |
| `contourability_field_peak_error_percent` | nan |
| `contourability_total_length_m` | nan |
| `layout_target_checked` | False |
| `layout_target_met` | True |
| `layout_target_metric` |  |
| `layout_target_metric_T` | 8.26678e-06 |
| `layout_target_limit_T` | nan |
| `layout_target_effective_limit_T` | nan |
| `layout_target_metric_ratio` | nan |
| `layout_target_source` | fabricated_centroid |
| `contourability_target_metric_T` | nan |
| `contourability_target_allowed_metric_T` | nan |
| `contour_field_smoothing_applied` | False |
| `contour_field_smoothing_improvement_percent` | nan |
| `contour_path_smoothing_scale_mode` | mesh_coupled |
| `contour_path_smoothing_mesh_scale_m` | 0.0150146 |
| `contour_path_smoothing_mesh_gain_requested` | 0.1 |
| `contour_path_smoothing_mesh_gain_applied` | 0.1 |
| `contour_path_smoothing_displacement_cap_enabled` | True |
| `contour_path_smoothing_max_applied_displacement_m` | 1.67418e-07 |
| `contour_path_smoothing_contour_count` | 32 |
| `contour_path_smoothing_spacing_rejected_count` | 0 |
| `contour_loop_pruning_mode` | off |
| `contour_loop_pruning_raw_loop_count` | 0 |
| `contour_loop_pruning_significance_removed_loop_count` | 0 |
| `contour_loop_pruning_removed_loop_count` | 0 |
| `contour_loop_pruning_baseline_metric_T` | nan |
| `contour_loop_pruning_allowed_metric_T` | nan |
| `contour_loop_pruning_selected_metric_T` | nan |
| `contour_loop_pruning_metric_change_T` | nan |
| `contour_loop_pruning_symmetry_grouping_complete` | False |
| `potential_step_A` | 11.6933 |
| `needed_current_A` | 11.6933 |
| `coil_length_m` | 18.9427 |
| `coil_length_total_m` | 18.9427 |
| `coil_electrical_calculation_status` | enabled |
| `coil_resistance_ohm` | 0.085242 |
| `coil_resistance_total_ohm` | 0.085242 |
| `coil_inductance_H` | 7.83367e-05 |
| `coil_inductance_same_current_H` | 7.83367e-05 |
| `min_contour_distance_m` | nan |
| `unconnected_contours_min_wire_distance_m` | nan |
| `min_wire_wire_distance_m` | 6.96272e-10 |
| `wire_clearance_failure_count` | 0 |
| `wire_clearance_failure_threshold_m` | 0 |
| `wire_clearance_warning_count` | 1 |
| `wire_clearance_warning_threshold_m` | 0.002 |
| `route_statuses` | fail |
| `stream_function_scheme` | research_convex |
| `regularization_method` | research_convex |
| `regularization_factor` | 0 |
| `regularization_lambda` | 0 |
| `regularization_auto_range` | False |
| `estimated_regularization_contour_step_A` | nan |
| `regularization_auto_range_max_contour_step_A` | nan |
| `target_error_contour_step_guard_relaxed_for_constraint` | False |
| `contour_step_constraint_enabled` | False |
| `contour_step_constraint_source` |  |
| `contour_step_constraint_max_step_A` | nan |
| `contour_step_constraint_level_count` | 0 |
| `contour_step_constraint_max_range_A` | nan |
| `surface_current_density_constraint_enabled` | False |
| `surface_current_density_constraint_source` |  |
| `surface_current_density_constraint_limit_A_per_m` | nan |
| `surface_current_density_constraint_derived_limit_A_per_m` | nan |
| `shield_gradient_opposition_requested` | False |
| `shield_gradient_opposition_enabled` | False |
| `shield_gradient_opposition_constraint_met` | True |
| `shield_gradient_opposition_value_T_per_m` | nan |
| `shield_gradient_opposition_limit_T_per_m` | nan |
| `shield_gradient_opposition_margin_T_per_m` | nan |
| `shield_gradient_opposition_reason` |  |
| `shield_gradient_opposition_part_indices` |  |
| `estimated_guarded_contour_step_A` | nan |
| `target_error_constraint_mode` | separate |
| `target_error_constraint_metric` | norm |
| `target_error_constraint_met` | True |
| `target_error_tolerance_percent` | 3 |
| `target_error_constraint_relative_residual_percent` | 3 |
| `target_error_constraint_field_metric_T` | 8.46403e-05 |
| `target_error_allowed_field_metric_T` | 8.46404e-05 |
| `linearity_rms_constraint_met` | False |
| `linearity_rms_constraint_field_metric_T` | nan |
| `linearity_rms_constraint_allowed_field_metric_T` | nan |
| `linearity_peak_constraint_met` | False |
| `linearity_peak_constraint_field_metric_T` | nan |
| `linearity_peak_constraint_allowed_field_metric_T` | nan |
| `gradient_strength_constraint_met` | False |
| `gradient_strength_constraint_field_metric_T` | nan |
| `gradient_strength_constraint_allowed_field_metric_T` | nan |
| `cross_gradient_constraint_met` | False |
| `cross_gradient_constraint_field_metric_T` | nan |
| `cross_gradient_constraint_allowed_field_metric_T` | nan |
| `target_error_auto_retry_count` | 0 |
| `target_error_auto_retry_selected_rerun` | 0 |
| `target_error_auto_retry_selected_violation_ratio` | nan |
| `dsv_constraint_met` | True |
| `dsv_constraint_metric` | norm |
| `dsv_constraint_weighting` | uniform |
| `dsv_constraint_residual_statistics_scope` | weighted_physical_field |
| `dsv_constraint_relative_residual_percent` | 3 |
| `dsv_constraint_allowed_residual_norm_T` | 8.46404e-05 |
| `dsv_constraint_field_metric_T` | 8.46403e-05 |
| `dsv_constraint_allowed_field_metric_T` | 8.46404e-05 |
| `dsv_constraint_allowed_with_acceptance_field_metric_T` | 8.47405e-05 |
| `dsv_constraint_std_T` | 5.27972e-06 |
| `dsv_constraint_allowed_std_T` | nan |
| `dsv_constraint_rms_residual_T` | 5.27972e-06 |
| `suppression_constraint_enabled` | False |
| `suppression_constraint_met` | False |
| `suppression_constraint_relative_residual_percent` | nan |
| `suppression_constraint_allowed_residual_norm_T` | nan |
| `suppression_constraint_rms_residual_T` | nan |
| `suppression_target_enabled` | False |
| `suppression_target_component` |  |
| `suppression_surface_weighting` |  |
| `suppression_target_sample_count` | 0 |
| `suppression_target_weight_mean` | nan |
| `suppression_target_rms_residual_T` | nan |
| `suppression_target_peak_abs_residual_T` | nan |
| `suppression_target_weighted_rms_residual_T` | nan |
| `suppression_field_rms_T` | nan |
| `suppression_field_rms_limit_T` | nan |
| `suppression_field_peak_T` | nan |
| `suppression_field_peak_limit_T` | nan |
| `suppression_clearance_status` | not_applicable |
| `suppression_clearance_generator` |  |
| `suppression_clearance_action` |  |
| `suppression_clearance_requested_m` | nan |
| `suppression_clearance_min_allowed_m` | nan |
| `suppression_clearance_min_m` | nan |
| `suppression_clearance_p05_m` | nan |
| `suppression_clearance_median_m` | nan |
| `suppression_clearance_max_m` | nan |
| `suppression_clearance_input_vertex_count` | 0 |
| `suppression_clearance_output_vertex_count` | 0 |
| `suppression_clearance_output_face_count` | 0 |
| `suppression_clearance_dropped_face_count` | 0 |
| `suppression_clearance_violation_count` | 0 |
| `suppression_clearance_warning` |  |
| `combined_weighted_residual_norm_T` | 8.46403e-05 |
| `constrained_solver_backend` | cvxpy_research |
| `constrained_solver_name` | CLARABEL |
| `constrained_solver_status` | optimal |
| `constrained_solver_contract_met` | True |
| `research_objective` | power |
| `sheet_power_W` | 8.01232 |
| `energy_J` | None |
| `force_N` | 0, 0, 0 |
| `torque_Nm` | -1.10405e-13, -1.19323e-13, 0 |
| `torque_origin_m` | 0, 0, 0 |
| `b0_T` | 0, 0, 3 |
| `force_model` | uniform_B0_total_closed_current_force_vanishes |
| `research_objective_scales` | {'power': 511.6638582246722} |
| `research_tolerance_scale` | 1 |
| `research_scenario_count` | 0 |
| `max_surface_current_density_A_per_m` | 2505.56 |
| `constrained_solver_physical_constraints_met` | True |
| `constrained_solver_diagnostic_result` | False |
| `constrained_solver_diagnostic_reason` |  |
| `constrained_solver_failed_constraints` |  |
| `constrained_solver_fallback_reason` |  |
| `stream_function_smoothness_enabled` | False |
| `stream_function_smoothness_factor` | nan |
| `stream_function_basis` |  |
| `stream_function_spectral_active` | False |
| `stream_function_spectral_unknown_count_before` | 0 |
| `stream_function_spectral_unknown_count_after` | 0 |
| `stream_function_spectral_reduction_factor` | nan |
| `stream_function_spectral_cutoff_length_m` | nan |
| `stream_function_spectral_min_retained_wavelength_m` | nan |
| `sensitivity_target_point_count` | 257 |
| `sensitivity_mesh_vertex_count` | 544 |
| `sensitivity_unknown_count` | 544 |
| `sensitivity_matrix_part_count` | 1 |
| `sensitivity_matrix_bytes` | 3355392 |
| `sensitivity_matrix_MiB` | 3.19995 |
| `sensitivity_matrix_shapes` | 3x257x544 |
| `execution_time_s` | 551.097 |
| `regularization_knee_type` | fixed |
| `regularization_residual_log_span` | nan |
| `regularization_resistance_log_span` | nan |
| `regularization_selected_residual_position` | nan |
| `regularization_selected_resistance_position` | nan |
| `selected_target_residual_norm_T_per_A` | 8.46403e-05 |
| `selected_resistance_seminorm_ohm_A` | nan |
| `gradient_slice_maps_enabled` | False |
| `gradient_slice_maps_status` | not_enabled |
| `concomitant_sample_count` | 257 |
| `concomitant_main_field_T` | 3 |
| `concomitant_b0_direction_x` | 0 |
| `concomitant_b0_direction_y` | 0 |
| `concomitant_b0_direction_z` | 1 |
| `concomitant_gradient_x_T_per_m` | 1.65693e-08 |
| `concomitant_gradient_y_T_per_m` | -2.92846e-06 |
| `concomitant_gradient_z_T_per_m` | 0.0191327 |
| `concomitant_rms_T` | 2.81114e-09 |
| `concomitant_p95_abs_T` | 4.95707e-09 |
| `concomitant_max_abs_T` | 6.10101e-09 |
| `concomitant_rms_ppm_of_B0` | 0.000937046 |
| `concomitant_p95_abs_ppm_of_B0` | 0.00165236 |
| `concomitant_max_abs_ppm_of_B0` | 0.00203367 |
| `concomitant_rms_percent_of_target_peak` | 0.000702785 |
| `concomitant_max_abs_percent_of_target_peak` | 0.00152525 |
| `concomitant_model` | linear_gradient_small_field_magnitude |
| `concomitant_assumption` | main field defines local z; fitted scalar gradient is B0-parallel |
| `concomitant_gradient_source` | connected_layout_fit_at_needed_current |
| `current_density_current_A` | 11.6933 |
| `current_density_conductor_width_m` | 0.002 |
| `current_density_conductor_height_m` | 0.002 |
| `current_density_conductor_area_m2` | 4e-06 |
| `current_density_A_per_m2` | 2.92332e+06 |
| `current_density_A_per_mm2` | 2.92332 |
| `current_density_class` | continuous_candidate |
| `current_density_assumption` | rectangular conductor cross section; no thermal duty-cycle model |
| `thermal_screening_status` | not_evaluated |
| `thermal_screening_included` | False |
| `thermal_screening_assumption` | no duty cycle, cooling, temperature-rise, or conductor insulation model evaluated |
| `engineering_readiness_status` | screening_only |
| `finished_engineering_design_ready` | False |
| `magnetostatic_status` | FAIL |
| `layout_status` | FAIL |
| `engineering_checks_not_included` | thermal; gradient-driver voltage/current margin; slew-rate validation; PNS; acoustic response; Lorentz force and torque; eddy-current coupling; cryostat or nearby-conductor heating; mechanical stress; terminal routing validation |
| `layout_gradient_efficiency_mT_per_m_per_A` | 1.63621 |
| `layout_field_efficiency_mT_per_A` | nan |
| `layout_needed_current_A` | 12.2233 |
| `layout_mean_rel_error_percent` | 0.59685 |
| `layout_max_rel_error_percent` | 4.09598 |
| `layout_fit_sample_count` | 257 |
| `layout_suppressed_rms_Bz_T_per_A` | nan |
| `layout_suppressed_peak_abs_Bz_T_per_A` | nan |
| `layout_suppressed_rms_Bmag_T_per_A` | nan |
| `layout_suppressed_peak_Bmag_T_per_A` | nan |
| `layout_suppressed_rms_Bz_T_at_fitted_current` | nan |
| `layout_suppressed_peak_abs_Bz_T_at_fitted_current` | nan |
| `layout_suppressed_rms_Bmag_T_at_fitted_current` | nan |
| `layout_suppressed_peak_Bmag_T_at_fitted_current` | nan |
| `unconnected_contours_gradient_efficiency_mT_per_m_per_A` | 1.67679 |
| `unconnected_contours_field_efficiency_mT_per_A` | nan |
| `unconnected_contours_needed_current_A` | 11.9276 |
| `unconnected_contours_mean_rel_error_percent` | 0.603836 |
| `unconnected_contours_max_rel_error_percent` | 4.14332 |
| `unconnected_contours_fit_sample_count` | 257 |
| `unconnected_contours_suppressed_rms_Bz_T_per_A` | nan |
| `unconnected_contours_suppressed_peak_abs_Bz_T_per_A` | nan |
| `unconnected_contours_suppressed_rms_Bmag_T_per_A` | nan |
| `unconnected_contours_suppressed_peak_Bmag_T_per_A` | nan |
| `unconnected_contours_suppressed_rms_Bz_T_at_fitted_current` | nan |
| `unconnected_contours_suppressed_peak_abs_Bz_T_at_fitted_current` | nan |
| `unconnected_contours_suppressed_rms_Bmag_T_at_fitted_current` | nan |
| `unconnected_contours_suppressed_peak_Bmag_T_at_fitted_current` | nan |
| `stream_function_gradient_efficiency_mT_per_m_per_A` | 1.67001 |
| `stream_function_field_efficiency_mT_per_A` | nan |
| `stream_function_needed_current_A` | 11.976 |
| `stream_function_mean_rel_error_percent` | 0.597588 |
| `stream_function_max_rel_error_percent` | 4.1088 |
| `stream_function_fit_sample_count` | 257 |
| `stream_function_suppressed_rms_Bz_T_per_A` | nan |
| `stream_function_suppressed_peak_abs_Bz_T_per_A` | nan |
| `stream_function_suppressed_rms_Bmag_T_per_A` | nan |
| `stream_function_suppressed_peak_Bmag_T_per_A` | nan |
| `stream_function_suppressed_rms_Bz_T_at_fitted_current` | nan |
| `stream_function_suppressed_peak_abs_Bz_T_at_fitted_current` | nan |
| `stream_function_suppressed_rms_Bmag_T_at_fitted_current` | nan |
| `stream_function_suppressed_peak_Bmag_T_at_fitted_current` | nan |
| `layout_gradient_offset_T` | -3.29331e-09 |
| `layout_gradient_dbz_dx_T_per_m` | 1.41699e-09 |
| `layout_gradient_dbz_dy_T_per_m` | -2.50439e-07 |
| `layout_gradient_dbz_dz_T_per_m` | 0.00163621 |
| `layout_gradient_desired_dbz_dx_T_per_m` | 6.93889e-18 |
| `layout_gradient_desired_dbz_dy_T_per_m` | 0 |
| `layout_gradient_desired_dbz_dz_T_per_m` | 0.02 |
| `layout_gradient_desired_T_per_m` | 0.02 |
| `layout_gradient_achieved_T_per_m` | 0.00163621 |
| `layout_gradient_cross_T_per_m` | 2.50443e-07 |
| `layout_gradient_cross_percent_of_desired` | 0.00125222 |
| `layout_gradient_alignment_cosine` | 1 |
| `layout_gradient_linear_rms_residual_T` | 2.71699e-07 |
| `layout_gradient_linear_rms_residual_percent_of_peak` | 0.0679247 |
| `layout_gradient_quadratic_rms_residual_T` | 2.71692e-07 |
| `layout_gradient_quadratic_rms_residual_percent_of_peak` | 0.0679229 |
| `layout_gradient_qxx_T_per_m2` | -6.15674e-07 |
| `layout_gradient_qyy_T_per_m2` | -7.34492e-07 |
| `layout_gradient_qzz_T_per_m2` | 1.35264e-06 |
| `layout_gradient_qxy_T_per_m2` | -1.00446e-05 |
| `layout_gradient_qxz_T_per_m2` | -2.42472e-05 |
| `layout_gradient_qyz_T_per_m2` | -1.37496e-05 |
| `layout_gradient_second_order_rms_T_per_m2` | 1.21149e-05 |
| `layout_gradient_fit_sample_count` | 257 |
| `symmetry_diagnostics_available` | False |
| `symmetry_reduction_active` | False |
| `symmetry_reduction_factor` | nan |
| `symmetry_reduction_unknown_count_before` | 0 |
| `symmetry_reduction_unknown_count_after` | 0 |
| `symmetry_reduction_reason` |  |
| `contour_symmetry_pair_count` | 0 |
| `contour_symmetry_failed_pair_count` | 0 |
| `symmetry_warning_count` | 0 |
| `symmetry_failure_count` | 0 |
| `coil_inductance_matrix_part_count` | 1 |
| `coil_inductance_self_part1_H` | 7.83367e-05 |
| `max_rel_error_layout_vs_target_percent` | 8.25482 |
| `mean_rel_error_layout_vs_target_percent` | 1.37855 |
| `max_rel_error_unconnected_contours_vs_target_percent` | 6.02606 |
| `mean_rel_error_unconnected_contours_vs_target_percent` | 0.733756 |
| `max_rel_error_layout_vs_stream_function_field_percent` | 2.0106 |
| `mean_rel_error_layout_vs_stream_function_field_percent` | 0.771316 |
| `max_rel_error_unconnected_contours_vs_stream_function_field_percent` | 0.387282 |
| `mean_rel_error_unconnected_contours_vs_stream_function_field_percent` | 0.157768 |

## Regularization Selection

| Quantity | Value |
|---|---:|
| `selection_method` | research_convex |
| `candidate_solver` |  |
| `selected_factor` | 0 |
| `selected_lambda` | 0 |
| `selected_index` | -1 |
| `candidate_count` | 0 |
| `valid_candidate_count` | 0 |
| `fallback` | False |
| `fallback_reason` |  |
| `knee_type` | fixed |
| `residual_log_span` | nan |
| `regularization_log_span` | nan |
| `selected_residual_position` | nan |
| `selected_regularization_position` | nan |
| `selected_curvature` | nan |
| `warnings` |  |

## DSV Field Error

| Quantity | Value |
|---|---:|
| `max_rel_error_layout_vs_target [%]` | 8.25482 |
| `mean_rel_error_layout_vs_target [%]` | 1.37855 |
| `max_rel_error_unconnected_contours_vs_target [%]` | 6.02606 |
| `mean_rel_error_unconnected_contours_vs_target [%]` | 0.733756 |
| `max_rel_error_layout_vs_stream_function_field [%]` | 2.0106 |
| `mean_rel_error_layout_vs_stream_function_field [%]` | 0.771316 |
| `max_rel_error_unconnected_contours_vs_stream_function_field [%]` | 0.387282 |
| `mean_rel_error_unconnected_contours_vs_stream_function_field [%]` | 0.157768 |

## Concomitant Field Report

Uses the fitted connected-layout gradient at the required target current. The model assumes the useful field component is parallel to the configured main field.

| Quantity | Value |
|---|---:|
| `concomitant_model` | linear_gradient_small_field_magnitude |
| `concomitant_assumption` | main field defines local z; fitted scalar gradient is B0-parallel |
| `concomitant_gradient_source` | connected_layout_fit_at_needed_current |
| `concomitant_main_field_T` | 3 |
| `concomitant_b0_direction_x` | 0 |
| `concomitant_b0_direction_y` | 0 |
| `concomitant_b0_direction_z` | 1 |
| `concomitant_gradient_x_T_per_m` | 1.65693e-08 |
| `concomitant_gradient_y_T_per_m` | -2.92846e-06 |
| `concomitant_gradient_z_T_per_m` | 0.0191327 |
| `concomitant_sample_count` | 257 |
| `concomitant_rms_T` | 2.81114e-09 |
| `concomitant_p95_abs_T` | 4.95707e-09 |
| `concomitant_max_abs_T` | 6.10101e-09 |
| `concomitant_rms_ppm_of_B0` | 0.000937046 |
| `concomitant_max_abs_ppm_of_B0` | 0.00203367 |
| `concomitant_rms_percent_of_target_peak` | 0.000702785 |
| `concomitant_max_abs_percent_of_target_peak` | 0.00152525 |

## Current-Density Report

Uses the configured conductor cross section and fitted layout current. It is not a thermal or duty-cycle calculation.

| Quantity | Value |
|---|---:|
| `current_density_current_A` | 11.6933 |
| `current_density_conductor_width_m` | 0.002 |
| `current_density_conductor_height_m` | 0.002 |
| `current_density_conductor_area_m2` | 4e-06 |
| `current_density_A_per_m2` | 2.92332e+06 |
| `current_density_A_per_mm2` | 2.92332 |
| `current_density_class` | continuous_candidate |
| `current_density_assumption` | rectangular conductor cross section; no thermal duty-cycle model |

## Inductance Matrix

Rows and columns are independent coil parts. Off-diagonal entries are mutual inductances; signs include the actual current/path orientation.

| `row` | `column` | `type` | `inductance_H` |
| --- | --- | --- | --- |
| 1 | 1 | self | 7.83367e-05 |

## Timing

| Quantity | Value |
|---|---:|
| `start` | 0.000 s; elapsed 0.000 s |
| `calculated potential levels` | 0.205 s; elapsed 0.205 s |
| `extracted contours` | 0.085 s; elapsed 0.290 s |
| `filtered loop significance` | 0.000 s; elapsed 0.290 s |
| `regularized contour paths` | 28.987 s; elapsed 29.277 s |
| `validated contourability` | 0.000 s; elapsed 29.277 s |
| `processed contour sparsification, pruning, and retained-contour consolidation` | 0.667 s; elapsed 29.944 s |
| `calculated contour distances` | 0.000 s; elapsed 29.944 s |
| `grouped contour topology` | 5.510 s; elapsed 35.454 s |
| `interconnected within loop groups` | 0.972 s; elapsed 36.427 s |
| `interconnected among loop groups` | 18.106 s; elapsed 54.532 s |
| `shifted return paths` | 3.400 s; elapsed 57.933 s |
| `cleaned wire paths` | 0.830 s; elapsed 58.762 s |
| `realized fabrication centerlines` | 13.077 s; elapsed 71.839 s |
| `selected joint group routes` | 466.007 s; elapsed 537.846 s |
| `finalized swept conductor meshes` | 10.319 s; elapsed 548.165 s |
| `calculated inductance and resistance` | 2.362 s; elapsed 550.527 s |
| `evaluated field errors` | 0.570 s; elapsed 551.097 s |

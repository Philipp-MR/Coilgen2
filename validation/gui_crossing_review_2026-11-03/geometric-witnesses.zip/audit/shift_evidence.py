"""Read the selected route's recorded lift diagnostics, before conductor mounting."""
import json
from pathlib import Path
from zipfile import ZipFile

from coilgen.pipeline_stages import _decode


def shift_evidence(run):
    with ZipFile(run / "checkpoints" / "routed.cgstage") as archive:
        manifest = json.loads(archive.read("manifest.json"))
    state = dict(manifest["payload"]["$dict"])["state"]["fields"]
    return [_decode(part["fields"]["normal_shift_diagnostics"], {}) for part in state["parts"]["$list"]]


if __name__ == "__main__":
    import sys
    print(json.dumps(shift_evidence(Path(sys.argv[1])), indent=2))

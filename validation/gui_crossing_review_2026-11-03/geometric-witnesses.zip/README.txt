Native CoilGen2 example crossing audit, 3 November 2026

Each of the 20 gallery entries was loaded through the offscreen Qt workbench on
one frozen source tree. Compute full design and Compute channels submitted 32
fresh jobs. The audit verified the result manifests and request and template
fingerprints. The native viewport subsequently reopened each original revision
and job. Its winding actors were compared point-for-point to the saved reviewed
conductor centerlines. Native receipts and version digests accompany the data.

Each JSON file under channels contains evidence for one design. The route is
the unmounted output, fabrication is the pipeline centroid, review is the
strictly reviewed mounted centroid, solid is the saved indexed pipeline mesh,
and review_solid is the actual exported fabrication STL. Coordinates are world
xyz in metres and all face and segment indices are zero-based. A completed
solver run can still fail its manufacturing checks.

Centerline contacts use finite 3-D line segments within 1e-9 m. Adjacent joins
and path visits separated along the wire by at most 1e-9 m are excluded. A
collinear adjacent retrace has a separate count. The clearance screen uses
the configured circumscribed profile diameter plus twice the insulation
thickness, manufacturing tolerance and bend clearance margin. The minimum
reported within that screen is over separated path visits more than four
screen distances apart along the same wire, or over distinct bodies.

Nondegenerate 3-D surface triangles are tested after a conservative bounding
box search. Expected shared vertices on neighboring stations are excluded.
The contact tolerance is 1e-12 m. A strict penetration witness requires an
edge to cross the interior of the other triangle with a positive margin to
the edges and vertices. Remote witnesses on the same body have more than
four bare profile diameters of intervening wire arclength. This separates a
return crossing another turn from a folded local sweep. Counts are pairs of
facets or segments and depend on tessellation. They are not counts of distinct
crossing locations. No insulation layer or external supply wiring is modeled
by the copper STLs.

Assembly checks compare separate channels in the same world coordinates.
A disjoint Cartesian or radial bound is a lower bound on copper-to-copper
distance. Each expanded design and each channel is listed separately in the
per-channel CSV. Example-specific witness records include owners, original
facet and segment IDs, and a world-coordinate point for each remote owner type.
The analytic and randomized audit fixtures are included beside the checker.

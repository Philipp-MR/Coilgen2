"""Independent 3-D checks of saved native workbench output. All distances are metres."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re

import numpy as np
from scipy.spatial import cKDTree


def dot(a, b):
    return np.einsum("ij,ij->i", a, b)


def candidates(low, high, tolerance):
    """Complete conservative AABB broad phase, binned by box radius for long connectors."""
    centers = (low + high) / 2
    radii = np.linalg.norm(high - low, axis=1) / 2
    rounding = 32 * np.finfo(float).eps * max(1.0, np.max(np.abs(centers)))
    order = np.floor(np.log2(np.maximum(radii, rounding))).astype(int)
    for exponent in np.unique(order):
        idx = np.flatnonzero(order == exponent)
        tree = cKDTree(centers[idx])
        maximum_radius = np.max(radii[idx])
        # Test smaller-to-bigger bins exactly once. In the same bin, compare indices.
        source = np.flatnonzero(order <= exponent)
        for start in range(0, len(source), 256):
            selected = source[start:start + 256]
            hits = tree.query_ball_point(centers[selected], radii[selected] + maximum_radius + np.sqrt(3)*tolerance + rounding)
            lengths = np.fromiter((len(group) for group in hits), int, len(hits))
            if not np.any(lengths):
                continue
            a = np.repeat(selected, lengths)
            b = idx[np.concatenate(hits).astype(int)]
            keep = ((order[a] != exponent) | (a < b)) & np.all(
                (low[a] <= high[b] + tolerance + rounding) & (low[b] <= high[a] + tolerance + rounding), axis=1
            )
            if np.any(keep):
                yield np.minimum(a[keep], b[keep]), np.maximum(a[keep], b[keep])


def nearest(p, p1, q, q1):
    """Evaluate the interior stationary point and all four edges of the [0,1]^2 domain."""
    u, v, w = p1 - p, q1 - q, q - p
    uu, vv = dot(u, u), dot(v, v)
    normal = np.cross(u, v)
    area_sq = dot(normal, normal)
    interior_a = np.divide(dot(np.cross(w, v), normal), area_sq, out=np.zeros_like(uu), where=area_sq > 0)
    interior_b = np.divide(dot(np.cross(w, u), normal), area_sq, out=np.zeros_like(uu), where=area_sq > 0)
    s = np.stack((interior_a, np.zeros_like(uu), np.ones_like(uu), dot(w, u) / uu, dot(q1 - p, u) / uu))
    t = np.stack((interior_b, dot(-w, v) / vv, dot(p1 - q, v) / vv, np.zeros_like(uu), np.ones_like(uu)))
    s = s.clip(0, 1)
    t = t.clip(0, 1)
    delta = s[:, :, None] * u - t[:, :, None] * v - w
    distances = np.einsum("ijk,ijk->ij", delta, delta)
    distances[0, (area_sq == 0) | (interior_a != s[0]) | (interior_b != t[0])] = np.inf
    best = np.argmin(distances, axis=0)
    col = np.arange(len(uu))
    return np.sqrt(distances[best, col]), s[best, col], t[best, col]


def audit_paths(paths, *, owners=None, closed_flags=None, clearance_m=0.0, tolerance_m=1e-9):
    """Mapping of named SI polylines, repeated point for closure, optional per-segment owner kinds.

    Centerline contacts include all non-neighboring intervals, including short local folds.
    Adjoining intervals also get a collinear-backtracking test. Envelope proximity uses an
    explicit local exclusion because neighboring intervals of any tube meet by construction.
    """
    names = list(paths)
    result = dict(path_count=len(names), segment_count=0, tolerance_m=tolerance_m, envelope_threshold_m=clearance_m,
                  centerline_contact_pairs=0, centerline_cross_path_pairs=0, centerline_local_join_pairs=0,
                  adjacent_retraces=0,
                  remote_envelope_pairs=0, minimum_remote_within_threshold_m=None,
                  contact_owners={}, envelope_owners={}, contact_examples=[], envelope_examples=[])
    if not names:
        return result
    chunks = []
    for k, name in enumerate(names):
        pts = np.asarray(paths[name], dtype=float)
        if pts.ndim != 2 or pts.shape[1] != 3 or not np.all(np.isfinite(pts)):
            raise ValueError(f"{name}: invalid path")
        length = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        usable = np.flatnonzero(length > 0)
        if not len(usable):
            continue
        p = pts[usable]
        q = pts[usable + 1]
        length = length[usable]
        arc = np.r_[0, np.cumsum(length)]
        closed = (closed_flags or {}).get(name,len(usable)>=3 and np.linalg.norm(p[0]-q[-1])<=1e-12)
        labels = np.asarray((owners or {}).get(name, ["unknown"] * (len(pts)-1)))[usable]
        local = np.arange(len(usable))
        chunks.append((p, q, np.full_like(local, k), usable, local, np.full_like(local,len(usable)),
                       np.full(len(local), arc[-1] if closed else np.inf), arc[:-1], length, labels))
    if not chunks:
        return result
    p, q, path, original, seq, nseg, total, arc, length, kind = (np.concatenate(fields) for fields in zip(*chunks))
    result["segment_count"] = len(p)
    min_remote = np.inf
    counts = [Counter(), Counter()]
    for a,b in candidates(np.minimum(p,q), np.maximum(p,q), max(clearance_m,tolerance_m)):
        same = path[a] == path[b]
        gap = seq[b] - seq[a]
        adjacent = same & ((gap == 1) | ((gap == nseg[a] - 1) & np.isfinite(total[a])))
        if np.any(adjacent):
            aa, bb = a[adjacent], b[adjacent]
            e, f = q[aa] - p[aa], q[bb] - p[bb]
            # Reversed collinear segments overlap along a positive length, unlike a shared endpoint.
            side = np.linalg.norm(np.cross(e, f),axis=1)/np.maximum(length[aa],length[bb])
            back = (dot(e,f)<0) & (side <= 1e-13) & (np.minimum(length[aa],length[bb])>tolerance_m)
            result["adjacent_retraces"] += int(np.sum(back))
        a,b = a[~adjacent],b[~adjacent]
        if not len(a):
            continue
        d,s,t = nearest(p[a],q[a],p[b],q[b])
        ds = np.abs(arc[a]+s*length[a]-arc[b]-t*length[b])
        along_path = np.maximum(0.0,np.minimum(ds,total[a]-ds))
        remote = (path[a]!=path[b]) | (along_path>4*clearance_m)
        # Short positive intervening segments can make both ends appear to touch at
        # audit resolution despite representing a single continuous visit of the wire.
        local_join = (path[a]==path[b]) & (along_path<=tolerance_m)
        result["centerline_local_join_pairs"] += int(((d<=tolerance_m)&local_join).sum())
        masks = ((d <= tolerance_m)&~local_join, remote & (d < clearance_m))
        result["centerline_contact_pairs"] += int(masks[0].sum())
        result["centerline_cross_path_pairs"] += int((masks[0] & (path[a]!=path[b])).sum())
        result["remote_envelope_pairs"] += int(masks[1].sum())
        if np.any(masks[1]):
            min_remote = min(min_remote, np.min(d[masks[1]]))
        for number, (mask, examples) in enumerate(zip(masks, ("contact_examples","envelope_examples"))):
            for index in np.flatnonzero(mask):
                first, second = a[index], b[index]
                counts[number][" / ".join(sorted((str(kind[first]), str(kind[second]))))] += 1
                if len(result[examples]) < 5 or d[index] < result[examples][-1]["distance_m"]:
                    row = dict(paths=[names[path[first]], names[path[second]]],
                               segments=[int(original[first]), int(original[second])],
                               owners=[str(kind[first]), str(kind[second])], distance_m=float(d[index]),
                               point_m=(p[first]+s[index]*(q[first]-p[first])).tolist())
                    result[examples] = sorted([*result[examples],row],key=lambda x:x["distance_m"])[:5]
    result["contact_owners"], result["envelope_owners"] = map(dict,counts)
    if np.isfinite(min_remote):
        result["minimum_remote_within_threshold_m"] = float(min_remote)
    return result


def triangle_intersections(a, b, tolerance=1e-12):
    """Separating-axis test on nondegenerate 3-D or coplanar triangles."""
    # Shift each pair near the origin to reduce projection cancellation.
    origin = a[:, :1].copy()
    a, b = a - origin, b - origin
    ea, eb = np.roll(a,-1,axis=1)-a, np.roll(b,-1,axis=1)-b
    na, nb = np.cross(ea[:,0],ea[:,1]), np.cross(eb[:,0],eb[:,1])
    axes = [na,nb]
    for i in range(3):
        # In-plane edge normals separate disjoint coplanar triangles.
        axes.extend((np.cross(na,ea[:,i]),np.cross(nb,eb[:,i])))
        axes.extend(np.cross(ea[:,i],eb[:,j]) for j in range(3))
    inside = np.ones(len(a),dtype=bool)
    for axis in axes:
        av = np.einsum("ijk,ik->ij",a,axis)
        bv = np.einsum("ijk,ik->ij",b,axis)
        margin = tolerance*np.linalg.norm(axis,axis=1)
        inside &= (av.max(axis=1)+margin >= bv.min(axis=1)) & (bv.max(axis=1)+margin >= av.min(axis=1))
    return inside


def interior_crossings(a,b,tolerance):
    """Witness crosses the interior of one triangle through the other triangle's edge."""
    witnesses=np.full((len(a),3),np.nan)
    for face,other in ((a,b),(b,a)):
        n=np.cross(other[:,1]-other[:,0],other[:,2]-other[:,0])
        n_norm=np.linalg.norm(n,axis=1)
        n=n/n_norm[:,None]
        heights=np.einsum("ijk,ik->ij",face-other[:,:1],n)
        for i in range(3):
            j=(i+1)%3
            denominator=heights[:,i]-heights[:,j]
            k=np.divide(heights[:,i],denominator,out=np.zeros_like(denominator),where=denominator!=0)
            point=face[:,i]+k[:,None]*(face[:,j]-face[:,i])
            ok=(np.minimum(heights[:,i],heights[:,j]) < -tolerance) & (np.maximum(heights[:,i],heights[:,j]) > tolerance)
            for h in range(3):
                edge=other[:,(h+1)%3]-other[:,h]
                # Strict positive in-plane distance to each triangle boundary.
                ok &= dot(np.cross(edge,point-other[:,h]),n)>tolerance*np.linalg.norm(edge,axis=1)
            witnesses[ok]=point[ok]
    return np.isfinite(witnesses[:,0]),witnesses


def audit_meshes(meshes, *, face_provenance=None, tolerance_m=1e-12):
    """All stored triangulated skins, skipping pairs that share a mesh vertex."""
    result = dict(body_count=len(meshes), face_count=0, degenerate_face_count=0, tolerance_m=tolerance_m,
                  contacting_triangle_pairs=0, cross_body_triangle_pairs=0, remote_triangle_pairs=0,
                  penetrating_triangle_pairs=0, remote_penetrating_triangle_pairs=0, remote_penetration_examples=[],
                  remote_penetration_by_owner={},
                  owner_pairs={}, remote_owner_pairs={}, body_pairs={}, examples=[], remote_examples=[])
    if not meshes:
        return result
    offset=0
    faces, vertices, body_ids, face_ids = [],[],[],[]
    names = list(meshes)
    for index,(vertices_i,faces_i) in enumerate(meshes.values()):
        faces.append(faces_i+offset)
        vertices.append(vertices_i)
        offset += len(vertices_i)
        body_ids.append(np.full(len(faces_i),index))
        face_ids.append(np.arange(len(faces_i)))
    vertices,faces = np.concatenate(vertices),np.concatenate(faces)
    body,face_id = np.concatenate(body_ids),np.concatenate(face_ids)
    tri = vertices[faces]
    area2 = np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
    valid = area2>0
    result["degenerate_face_count"] = int(np.sum(~valid))
    result["face_count"] = len(faces)
    # STL exports drop vertex indices. Welding equal coordinates recovers the normal mesh
    # connectivity, but two remote stations can coincide exactly. Their equal coordinates
    # must still be tested. Only neighboring stations can truly share a sweep vertex.
    station = np.full(len(faces),-1)
    nstation = np.zeros(len(faces),dtype=int)
    cyclic = np.zeros(len(faces),dtype=bool)
    for index,name in enumerate(names):
        if not face_provenance or name not in face_provenance:
            continue
        nsection,labels,_,closed,_ = face_provenance[name]
        mask = body==index
        idx = face_id[mask]
        segment = idx//(2*nsection)
        cap = segment >= len(labels)
        segment[cap] = np.where(idx[cap]%2,len(labels)-1,0)
        station[mask],nstation[mask],cyclic[mask] = segment,len(labels),closed
    counts, owner_counts, remote_counts = Counter(), Counter(), Counter()
    for a,b in candidates(tri.min(axis=1),tri.max(axis=1),tolerance_m):
        delta = np.abs(station[a]-station[b])
        possible_neighbor = (body[a]==body[b]) & ((station[a]<0) | (delta<=1) | (cyclic[a] & (delta==nstation[a]-1)))
        common = np.any(faces[a,:,None]==faces[b,None,:],axis=(1,2))
        keep = valid[a] & valid[b] & ~(possible_neighbor & common)
        a,b = a[keep],b[keep]
        if not len(a):
            continue
        hit = triangle_intersections(tri[a],tri[b],tolerance_m)
        if not np.any(hit):
            continue
        aa,bb=a[hit],b[hit]
        penetrate,witnesses=interior_crossings(tri[aa],tri[bb],tolerance_m)
        for first,second,interior,point in zip(aa,bb,penetrate,witnesses):
            k,l = body[first],body[second]
            counts[f"{names[k]} / {names[l]}"] += 1
            result["contacting_triangle_pairs"] += 1
            result["cross_body_triangle_pairs"] += int(k!=l)
            row = dict(bodies=[names[k],names[l]],faces=[int(face_id[first]),int(face_id[second])])
            owner = "unknown"
            remote = k!=l
            if face_provenance and names[k] in face_provenance and names[l] in face_provenance:
                own = []
                intervals = []
                for i,which in ((first,k),(second,l)):
                    nsection, labels, cumulative, closed, diameter = face_provenance[names[which]]
                    ring = int(face_id[i]//(2*nsection))
                    # Cap triangles are appended in alternating start, end order.
                    if ring >= len(labels):
                        ring = (len(labels)-1) if face_id[i]%2 else 0
                    own.append(str(labels[ring]))
                    intervals.append(ring)
                row.update(owners=own, segments=intervals)
                owner = " / ".join(sorted(own))
                owner_counts[owner] += 1
                if k==l:
                    i,j = sorted(intervals)
                    gap = max(0.0, cumulative[j] - cumulative[i+1])
                    if closed:
                        gap = min(gap, cumulative[-1]-cumulative[j+1]+cumulative[i])
                    remote = gap > 4*diameter
                if remote:
                    remote_counts[owner] += 1
            if remote:
                result["remote_triangle_pairs"] += 1
                if len(result["remote_examples"])<5:
                    result["remote_examples"].append(row)
            if interior:
                result["penetrating_triangle_pairs"] += 1
                if remote:
                    result["remote_penetrating_triangle_pairs"] += 1
                    if len(result["remote_penetration_examples"]) < 5:
                        result["remote_penetration_examples"].append(dict(row,point_m=point.tolist()))
                    if owner not in result["remote_penetration_by_owner"]:
                        result["remote_penetration_by_owner"][owner]=dict(row,point_m=point.tolist())
            if len(result["examples"]) < 5:
                result["examples"].append(row)
    result["body_pairs"] = dict(counts)
    result["owner_pairs"] = dict(owner_counts)
    result["remote_owner_pairs"] = dict(remote_counts)
    return result


def stl_mesh(path):
    """Rebuild indexed triangles without reordering the stored facets."""
    raw=Path(path).read_bytes()
    if raw.lstrip().startswith(b"solid") and b"vertex " in raw[:1024]:
        rows=re.findall(rb"(?:^|\n)\s*vertex\s+([^\r\n]+)",raw)
        points=np.fromstring(b" ".join(rows),sep=" ").reshape(-1,3)
    else:
        n=int.from_bytes(raw[80:84],"little")
        if len(raw)!=84+50*n:
            raise ValueError(f"invalid STL {path}")
        record=np.dtype([("normal","<f4",3),("points","<f4",(3,3)),("attribute","<u2")])
        points=np.frombuffer(raw,record,count=n,offset=84)["points"].reshape(-1,3).astype(float)
    vertices,inverse=np.unique(points,axis=0,return_inverse=True)
    return vertices,inverse.reshape(-1,3)


def station_provenance(d,names,f):
    if f+"_frame_cross_section_m" not in names or f+"_points_m" not in names:
        return None
    profile,pts = d[f+"_frame_cross_section_m"],d[f+"_points_m"]
    cumulative = np.r_[0.0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
    diameter = np.max(np.linalg.norm(profile[:,None]-profile[None,:],axis=2))
    labels = d[f+"_owner_kind"] if f+"_owner_kind" in names else np.repeat("unknown",len(pts)-1)
    return len(profile),labels,cumulative,bool(d[f+"_frame_closed"]),diameter


def audit_saved(scientific_result_npz, *, clearance_m=0.0, solids=True):
    with np.load(scientific_result_npz, allow_pickle=False) as d:
        names = set(d.files)
        route = sorted(k[:-9] for k in names if re.fullmatch(r"route_\d+_points_m",k))
        fabrication = sorted(k[:-9] for k in names if re.fullmatch(r"fabrication_\d+(?:_\d+)?_points_m",k))
        # Per-part and body-0 paths can be aliases for the same physical winding.
        fabrication = [k for k in fabrication if len(k.split("_"))==3 or not any(v.startswith(k+"_") for v in fabrication)]
        out = {}
        review = sorted((k[:-9] for k in names if re.fullmatch(r"review_conductor_\d+_points_m",k)),
                        key=lambda k:int(k.rsplit("_",1)[1]))
        for label,keys in (("route",route),("fabrication",fabrication),("review",review)):
            paths = {k:d[k+"_points_m"] for k in keys}
            owners = {k:d[k+"_owner_kind"] for k in keys if k+"_owner_kind" in names}
            closed = {k:bool(d[k+"_frame_closed"]) for k in keys if k+"_frame_closed" in names}
            out[label]=audit_paths(paths,owners=owners,closed_flags=closed,clearance_m=clearance_m)
        electrical=sorted(k[:-9] for k in names if re.fullmatch(r"review_electrical_\d+_points_m",k))
        extra=[]
        for k in electrical:
            base=k.replace("electrical","conductor")+"_points_m"
            if base not in names or not np.array_equal(d[k+"_points_m"],d[base]):
                extra.append(k)
        out["electrical"]=dict(recorded_paths=len(electrical),reviewed_bodies=len(review),
                               distinct_electrical_paths=extra)
        if extra:
            out["electrical"]["centerline"]=audit_paths({k:d[k+"_points_m"] for k in electrical},clearance_m=clearance_m)
        if solids:
            meshes = sorted(k[:-11] for k in names if re.fullmatch(r"swept_\d+_\d+_vertices_m",k))
            metadata = {}
            for k in meshes:
                f = k.replace("swept_","fabrication_",1)
                metadata[k]=station_provenance(d,names,f)
            metadata = {k:v for k,v in metadata.items() if v is not None}
            out["solid"]=audit_meshes({k:(d[k+"_vertices_m"],d[k+"_faces"]) for k in meshes},
                                     face_provenance=metadata)
            out["solid"]["body_provenance_count"] = len(metadata)
            review_dir = Path(scientific_result_npz).parent/"fabrication"
            report_file = review_dir/"fabrication_report.json"
            review_meshes, review_meta, sources, missing = {},{},{},[]
            if report_file.is_file():
                report=json.loads(report_file.read_text(encoding="utf-8"))
                for i,record in enumerate(report["paths"]):
                    k=record["body_id"]
                    files=[p for p in (review_dir/(k+"_fabrication.stl"),review_dir/(k+"_DRAFT_fabrication.stl")) if p.exists()]
                    if not files:
                        missing.append(k)
                        continue
                    if len(files)!=1:
                        raise ValueError(f"ambiguous STL for {k} in {review_dir}")
                    vertices,faces=stl_mesh(files[0])
                    if len(faces)!=int(record["diagnostics"]["face_count"]):
                        raise ValueError(f"recorded and STL face counts differ for {k}")
                    review_meshes[k]=vertices,faces
                    sources[k]=files[0].name
                    provenance=station_provenance(d,names,f"review_conductor_{i}")
                    if provenance is not None:
                        review_meta[k]=provenance
            out["review_solid"]=audit_meshes(review_meshes,face_provenance=review_meta)
            out["review_solid"].update(source_files=sources,missing_stl=missing,body_provenance_count=len(review_meta))
        return out


if __name__ == "__main__":
    cli = argparse.ArgumentParser()
    cli.add_argument("scientific_result_npz")
    cli.add_argument("--clearance-m", type=float, default=0.0)
    cli.add_argument("--skip-solids", action="store_true")
    args = cli.parse_args()
    print(json.dumps(audit_saved(args.scientific_result_npz,clearance_m=args.clearance_m,solids=not args.skip_solids),indent=2))
